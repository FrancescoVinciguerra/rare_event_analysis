from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess

import pytest


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


def _bash_executable() -> str:
    configured = os.environ.get("BASH_EXE")
    candidates = [
        configured,
        shutil.which("bash"),
        r"C:\Program Files\Git\bin\bash.exe",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(candidate)
    pytest.skip("Bash is unavailable")


def _dry_run(stage: str) -> str:
    environment = os.environ.copy()
    environment.update(
        {
            "AVON_ACCOUNT": "stats",
            "AVON_PARTITION": "gpu-devel",
            "AVON_GPU_GRES": "gpu:quadro_rtx_6000:1",
            "AVON_MODULES": "GCCcore/13.2.0 Python/3.11.5",
        }
    )
    result = subprocess.run(
        [_bash_executable(), "scripts/submit_avon_first_experiment.sh", stage],
        cwd=REPOSITORY_ROOT,
        env=environment,
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout


def test_all_avon_shell_scripts_pass_bash_syntax() -> None:
    scripts = sorted((REPOSITORY_ROOT / "scripts").glob("*.sh"))
    assert scripts
    subprocess.run(
        [_bash_executable(), "-n", *[str(path) for path in scripts]],
        cwd=REPOSITORY_ROOT,
        check=True,
    )


def test_calibration_report_dry_run_is_cpu_only() -> None:
    output = _dry_run("calibration-report")
    assert "partition=devel" in output
    assert "gres=none" in output
    assert "cpus_per_task=2" in output
    assert "memory=4G" in output
    command = next(line for line in output.splitlines() if line.startswith("command="))
    assert "--partition=devel" in command
    assert "--cpus-per-task=2" in command
    assert "--mem=4G" in command
    assert "--time=00:10:00" in command
    assert "--gres" not in command


def test_direct_256_dry_run_retains_gpu_resources() -> None:
    output = _dry_run("direct-256")
    assert "partition=gpu-devel" in output
    assert "gres=gpu:quadro_rtx_6000:1" in output
    assert "cpus_per_task=4" in output
    assert "memory=16G" in output
    command = next(line for line in output.splitlines() if line.startswith("command="))
    assert "--gres=gpu:quadro_rtx_6000:1" in command
    assert "--time=00:45:00" in command
