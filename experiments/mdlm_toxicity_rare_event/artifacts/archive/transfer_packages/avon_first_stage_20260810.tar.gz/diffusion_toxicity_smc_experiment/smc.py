"""SMC on the native MDLM reverse chain and component-wise reverse-SNIS."""

from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Any, Callable, Sequence

import torch

from .ancestral import NativeMDLMSampler


RewardFunction = Callable[[torch.Tensor], torch.Tensor]
EventFunction = Callable[[torch.Tensor], torch.Tensor]


def normalize_log_weights(log_weights: torch.Tensor) -> torch.Tensor:
    log_weights = torch.as_tensor(log_weights, dtype=torch.float64)
    if log_weights.ndim != 1 or log_weights.numel() == 0:
        raise ValueError("log_weights must be a non-empty vector")
    if bool(torch.isnan(log_weights).any().item()) or bool(torch.isposinf(log_weights).any().item()):
        raise ValueError("log_weights may be finite or -inf, but not NaN/+inf")
    normalizer = torch.logsumexp(log_weights, dim=0)
    if not bool(torch.isfinite(normalizer).item()):
        raise ValueError("at least one log weight must be finite")
    return log_weights - normalizer


def ess_from_log_weights(normalized_log_weights: torch.Tensor) -> float:
    normalized = normalize_log_weights(normalized_log_weights)
    return float(torch.exp(-torch.logsumexp(2.0 * normalized, dim=0)).item())


def resample_indices(
    normalized_log_weights: torch.Tensor,
    *,
    method: str,
    generator: torch.Generator,
) -> torch.Tensor:
    log_weights = normalize_log_weights(normalized_log_weights)
    weights = log_weights.exp()
    count = weights.numel()
    if method == "multinomial":
        return torch.multinomial(weights, count, replacement=True, generator=generator)
    if method == "systematic":
        start = torch.rand((), device=weights.device, generator=generator) / count
        points = start + torch.arange(count, device=weights.device) / count
    elif method == "stratified":
        points = (
            torch.arange(count, device=weights.device)
            + torch.rand(count, device=weights.device, generator=generator)
        ) / count
    else:
        raise ValueError("resampling method must be multinomial, systematic, or stratified")
    cumulative = torch.cumsum(weights, dim=0)
    cumulative[-1] = 1.0
    return torch.searchsorted(cumulative, points, right=False)


def beta_at_level(
    *, level: int, terminal_level: int, lambda_final: float, start_fraction: float
) -> float:
    if level <= 0:
        return 0.0
    if level >= terminal_level:
        return float(lambda_final)
    fraction = level / terminal_level
    if fraction <= start_fraction:
        return 0.0
    return float(lambda_final) * (fraction - start_fraction) / (1.0 - start_fraction)


def telescoping_log_increments(beta: Sequence[float], rewards: Sequence[float]) -> list[float]:
    if len(beta) != len(rewards) or len(beta) < 2:
        raise ValueError("beta and rewards must have equal length >= 2")
    potentials = [float(b) * float(r) for b, r in zip(beta, rewards)]
    return [current - previous for previous, current in zip(potentials, potentials[1:])]


@dataclass(frozen=True)
class ReverseSNISResult:
    estimate: float
    corrected_ess: float
    corrected_ess_over_n: float
    corrected_log_weights: tuple[float, ...]
    event_discoveries: int
    tilted_event_fraction: float


def reverse_snis_component(
    *,
    final_log_weights: torch.Tensor,
    rewards: torch.Tensor,
    events: torch.Tensor,
    lambda_final: float,
) -> ReverseSNISResult:
    """Consistent component-wise SNIS correction; generally biased at finite N."""

    log_weights = normalize_log_weights(final_log_weights.double())
    rewards = torch.as_tensor(rewards, dtype=torch.float64, device=log_weights.device)
    events = torch.as_tensor(events, dtype=torch.bool, device=log_weights.device)
    if rewards.shape != log_weights.shape or events.shape != log_weights.shape:
        raise ValueError("weights, rewards, and events must have the same shape")
    corrected = normalize_log_weights(log_weights - float(lambda_final) * rewards)
    probabilities = corrected.exp()
    estimate = float(torch.sum(probabilities * events.double()).item())
    ess = ess_from_log_weights(corrected)
    discoveries = int(events.sum().item())
    return ReverseSNISResult(
        estimate=estimate,
        corrected_ess=ess,
        corrected_ess_over_n=ess / events.numel(),
        corrected_log_weights=tuple(float(value) for value in corrected.cpu().tolist()),
        event_discoveries=discoveries,
        tilted_event_fraction=discoveries / events.numel(),
    )


def aggregate_component_estimates(
    estimates: Sequence[float], coefficients: Sequence[float]
) -> float:
    if len(estimates) == 0 or len(estimates) != len(coefficients):
        raise ValueError("one coefficient is required per component")
    weights_a = torch.tensor(coefficients, dtype=torch.float64)
    if bool((weights_a < 0).any().item()) or not math.isclose(
        float(weights_a.sum()), 1.0, abs_tol=1e-9
    ):
        raise ValueError("component coefficients must be non-negative and sum to one")
    estimate_tensor = torch.tensor(estimates, dtype=torch.float64)
    if not bool(torch.isfinite(estimate_tensor).all().item()):
        raise FloatingPointError("component estimates contain NaN or Inf")
    return float(torch.dot(weights_a, estimate_tensor).item())


@dataclass(frozen=True)
class SMCComponentConfig:
    num_particles: int
    num_steps: int
    sequence_length: int
    lambda_final: float
    ess_threshold: float = 0.5
    resampling_method: str = "multinomial"
    reward_frequency: int = 20
    beta_start_fraction: float = 0.0
    final_resampling: bool = False
    microbatch_size: int | None = None
    seed: int = 1234

    def __post_init__(self) -> None:
        if self.num_particles <= 0 or self.num_steps <= 0 or self.sequence_length <= 0:
            raise ValueError("particle, step, and length counts must be positive")
        if not 0.0 <= self.ess_threshold <= 1.0:
            raise ValueError("ess_threshold must be in [0, 1]")
        if self.resampling_method not in {"multinomial", "systematic", "stratified"}:
            raise ValueError("invalid resampling method")
        if self.reward_frequency <= 0:
            raise ValueError("reward_frequency must be positive")
        if self.microbatch_size is not None and self.microbatch_size <= 0:
            raise ValueError("microbatch_size must be positive when provided")
        if not 0.0 <= self.beta_start_fraction < 1.0:
            raise ValueError("beta_start_fraction must be in [0, 1)")


@dataclass
class SMCComponentResult:
    terminal_tokens: torch.Tensor
    rewards: torch.Tensor
    events: torch.Tensor
    final_log_weights: torch.Tensor
    pre_final_resampling_log_weights: torch.Tensor
    post_final_resampling_log_weights: torch.Tensor
    root_ancestors: torch.Tensor
    genealogy: list[dict[str, Any]]
    level_diagnostics: list[dict[str, Any]]
    reverse_snis: ReverseSNISResult
    log_normalizer_estimate: float
    nfe: int
    runtime_seconds: float


def _apply_potential(
    *,
    log_weights: torch.Tensor,
    current_log_potential: torch.Tensor,
    previous_log_potential: torch.Tensor,
) -> tuple[torch.Tensor, float]:
    unnormalized = log_weights + current_log_potential - previous_log_potential
    log_increment = torch.logsumexp(unnormalized, dim=0)
    return unnormalized - log_increment, float(log_increment.item())


@torch.inference_mode()
def run_smc_component(
    *,
    sampler: NativeMDLMSampler,
    fixed_prefix_token_ids: torch.Tensor | None,
    reward_fn: RewardFunction,
    event_fn: EventFunction,
    config: SMCComponentConfig,
    device: torch.device | str,
) -> SMCComponentResult:
    device = torch.device(device)
    generator = torch.Generator(device=device.type).manual_seed(config.seed)
    count = config.num_particles
    states, prefix = sampler.initial_states(
        batch_size=count,
        sequence_length=config.sequence_length,
        device=device,
        fixed_prefix_token_ids=fixed_prefix_token_ids,
    )
    log_weights = torch.full(
        (count,), -math.log(count), dtype=torch.float64, device=device
    )
    previous_log_potential = torch.zeros(count, dtype=torch.float64, device=device)
    root_ancestors = torch.arange(count, device=device)
    genealogy: list[dict[str, Any]] = []
    diagnostics: list[dict[str, Any]] = []
    log_z = 0.0
    sampler.reset_nfe()
    started = time.perf_counter()
    dt_value = (1.0 - sampler.sampling_epsilon) / config.num_steps
    times = torch.linspace(1.0, sampler.sampling_epsilon, config.num_steps + 1).tolist()
    cache = None
    terminal_level = config.num_steps

    for step, t_scalar in enumerate(times[:-1], start=1):
        states, cache = sampler.ddpm_step(
            states,
            t_scalar=float(t_scalar),
            dt=dt_value,
            generator=generator,
            cached_p_x0=cache,
            microbatch_size=config.microbatch_size,
        )
        # The final checkpoint is always evaluated below on the true stochastic
        # terminal completion.  Never insert an argmax rollout at the same level.
        score_level = step % config.reward_frequency == 0 and step < config.num_steps
        resampled = False
        ess = ess_from_log_weights(log_weights)
        if score_level and config.lambda_final != 0.0:
            provisional = states
            if bool((states == sampler.mask_token_id).any().item()):
                provisional = sampler.deterministic_completion(
                    states,
                    t_scalar=float(times[step]),
                    microbatch_size=config.microbatch_size,
                )
            rewards = reward_fn(provisional).to(device=device, dtype=torch.float64)
            if not bool(torch.isfinite(rewards).all().item()):
                raise FloatingPointError("intermediate rewards contain NaN or Inf")
            beta = beta_at_level(
                level=step,
                terminal_level=terminal_level,
                lambda_final=config.lambda_final,
                start_fraction=config.beta_start_fraction,
            )
            current = beta * rewards
            log_weights, log_increment = _apply_potential(
                log_weights=log_weights,
                current_log_potential=current,
                previous_log_potential=previous_log_potential,
            )
            log_z += log_increment
            previous_log_potential = current
            ess = ess_from_log_weights(log_weights)
            max_weight = float(log_weights.max().exp().item())
            if ess < config.ess_threshold * count:
                parents = resample_indices(
                    log_weights, method=config.resampling_method, generator=generator
                )
                states = states[parents]
                root_ancestors = root_ancestors[parents]
                previous_log_potential = previous_log_potential[parents]
                log_weights.fill_(-math.log(count))
                cache = None
                resampled = True
                genealogy.append(
                    {
                        "level": step,
                        "parents": [int(value) for value in parents.cpu().tolist()],
                        "distinct_root_ancestors": len(
                            set(int(value) for value in root_ancestors.cpu().tolist())
                        ),
                    }
                )
        else:
            max_weight = float(log_weights.max().exp().item())
        diagnostics.append(
            {
                "level": step,
                "ess": ess,
                "checkpoint": bool(score_level and config.lambda_final != 0.0),
                "beta": (
                    beta_at_level(
                        level=step,
                        terminal_level=terminal_level,
                        lambda_final=config.lambda_final,
                        start_fraction=config.beta_start_fraction,
                    )
                    if score_level and config.lambda_final != 0.0
                    else None
                ),
                "ess_before_resampling": (
                    ess if score_level and config.lambda_final != 0.0 else None
                ),
                "max_normalized_weight_before_resampling": (
                    max_weight if score_level and config.lambda_final != 0.0 else None
                ),
                "resampled": resampled,
                "distinct_root_ancestors": len(
                    set(int(value) for value in root_ancestors.cpu().tolist())
                ),
            }
        )

    if sampler.final_noise_removal:
        states = sampler.terminal_completion(
            states,
            t_scalar=sampler.sampling_epsilon,
            generator=generator,
            microbatch_size=config.microbatch_size,
        )
    if bool((states == sampler.mask_token_id).any().item()):
        raise RuntimeError("terminal particles still contain masks")
    terminal_rewards = reward_fn(states).to(device=device, dtype=torch.float64)
    if not bool(torch.isfinite(terminal_rewards).all().item()):
        raise FloatingPointError("terminal rewards contain NaN or Inf")
    terminal_events = event_fn(states).to(device=device, dtype=torch.bool)
    if prefix.numel() and not torch.equal(
        states[:, : prefix.numel()], prefix.expand(count, -1)
    ):
        raise RuntimeError("fixed prefix changed during SMC propagation")
    current = float(config.lambda_final) * terminal_rewards
    log_weights, log_increment = _apply_potential(
        log_weights=log_weights,
        current_log_potential=current,
        previous_log_potential=previous_log_potential,
    )
    log_z += log_increment
    terminal_ess = ess_from_log_weights(log_weights)
    pre_final_resampling_log_weights = log_weights.clone()
    if config.final_resampling:
        parents = resample_indices(
            log_weights, method=config.resampling_method, generator=generator
        )
        states = states[parents]
        terminal_rewards = terminal_rewards[parents]
        terminal_events = terminal_events[parents]
        root_ancestors = root_ancestors[parents]
        log_weights.fill_(-math.log(count))
        genealogy.append(
            {
                "level": terminal_level,
                "parents": [int(value) for value in parents.cpu().tolist()],
                "final_resampling": True,
            }
        )
    diagnostics.append(
        {
            "level": terminal_level,
            "ess": terminal_ess,
            "checkpoint": True,
            "beta": float(config.lambda_final),
            "ess_before_resampling": terminal_ess,
            "max_normalized_weight_before_resampling": float(
                pre_final_resampling_log_weights.max().exp().item()
            ),
            "ess_after_resampling": ess_from_log_weights(log_weights),
            "max_normalized_weight_after_resampling": float(
                log_weights.max().exp().item()
            ),
            "resampled": bool(config.final_resampling),
            "terminal": True,
            "distinct_root_ancestors": len(
                set(int(value) for value in root_ancestors.cpu().tolist())
            ),
        }
    )
    post_final_resampling_log_weights = log_weights.clone()
    reverse = reverse_snis_component(
        final_log_weights=log_weights,
        rewards=terminal_rewards,
        events=terminal_events,
        lambda_final=config.lambda_final,
    )
    return SMCComponentResult(
        terminal_tokens=states,
        rewards=terminal_rewards,
        events=terminal_events,
        final_log_weights=log_weights,
        pre_final_resampling_log_weights=pre_final_resampling_log_weights,
        post_final_resampling_log_weights=post_final_resampling_log_weights,
        root_ancestors=root_ancestors,
        genealogy=genealogy,
        level_diagnostics=diagnostics,
        reverse_snis=reverse,
        log_normalizer_estimate=log_z,
        nfe=sampler.nfe,
        runtime_seconds=time.perf_counter() - started,
    )
