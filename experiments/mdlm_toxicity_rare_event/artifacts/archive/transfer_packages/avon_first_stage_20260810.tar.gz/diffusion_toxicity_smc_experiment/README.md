# Unconditional MDLM toxicity rare-event benchmark

This package tests the rare-event estimator on the unconditional distribution
of the frozen MDLM-OWT model. It does **not** reproduce the prompt-conditioned
FK Steering experiment and its result must not be compared with FK's reported
prompt-conditioned toxicity rate.

## Base distribution

The decoder starts from

```text
Y_0 = [MASK]^128
```

with no BOS, EOS, prompt, or clamped prefix. This matches MDLM commit
`c112c526d193436838c98d81455ee51f90309470`: `Diffusion._sample_prior`
returns `mask_index * ones(*batch_dims)`, and the diffusion `_sample` method
uses it for the full configured model length. The BOS insertion in that source
belongs only to the separate autoregressive sampler.

The decoder manifest records `generation_mode: unconditional`,
`fixed_prefix_token_ids: []`, and `prompt: null`. Changing from a fixed-prefix
decoder to unconditional generation necessarily changes `decoder_id`, so old
prompt-conditioned artifacts cannot be reused.

The native SUBS DDPM propagation remains stochastic. Any masks remaining after
the last DDPM step are removed by a categorical draw from the model
distribution (`final_noise_removal_method: stochastic_categorical`), not by
argmax. At SMC reward checkpoints only, every remaining mask is filled by a
deterministic MDLM argmax, scored, and discarded; the actual particle state is
never replaced by that provisional completion.

The first estimative benchmark fixes this decoder at 32 DDPM steps. It estimates
`P_{X ~ P0^(32)}(E(X)=1)` and must not be described as the standard 1000-step
MDLM probability. A later 1000-step benchmark requires a distinct `decoder_id`
and its own IID direct baseline.

## Toxicity event

The classifier and RoBERTa retokenization/truncation convention are inherited
from the FK code, but their input is generated text only:

- reward: positive-class log probability on the first configured MDLM tokens;
- event: classifier `argmax == 1` after the generated text is retokenized by
  pinned `roberta-large` and truncated to 50 tokens.

The classifier, revisions, tokenization, truncation, text scope, and event rule
form the `evaluator_id`.

## Terminal-lambda calibration

`configs/mdlm_owt_unconditional_lambda_calibration.yaml` runs separate SMC
components at terminal lambdas 0.5, 1, 2, and 4 with 64 particles. Lambda zero
is a separate base-sampler diagnostic. Calibration components are never
aggregated and their mean is not an estimator.

For a component ending at `lambda_j`, checkpoint levels are 4, 8, ..., 32 and

```text
beta_j,t = lambda_j * t / 32.
```

Levels 4 through 28 use a disposable deterministic argmax completion only when
masks remain. Level 32 is evaluated on the true terminal stochastic completion.
The incremental log potential is

```text
beta_j,t * R_t - beta_j,previous * R_previous,
```

so the full product telescopes to `exp(lambda_j * R_32)`. The calibration
artifacts keep reverse-SNIS ESS, genealogical diversity, resampling, reward,
classifier, runtime, NFE, memory, and finite-value diagnostics separate for
every lambda.

`configs/mdlm_owt_unconditional_estimation_template.yaml` is deliberately
provisional. Its terminal lambdas must be reviewed after calibration. Only
estimation components use the uniform component average; lambda zero is
excluded and particles are never pooled across components.

## IID direct baseline

Direct samples are IID draws `X_i ~ P0`. The estimator is

```text
p_hat_MC = (1/N) sum_i 1_E(X_i).
```

The report includes the binomial standard error and Wilson interval. There is
no prompt index, prompt mixture, stratified variance, or macro-average.

Generation and scoring remain separate and resumable:

```bash
python -m diffusion_toxicity_smc_experiment.generate_direct \
  --config configs/mdlm_owt_unconditional_smoke_technical.yaml \
  --target-samples 2

python -m diffusion_toxicity_smc_experiment.score_direct \
  --config configs/mdlm_owt_unconditional_smoke_technical.yaml
```

Artifacts are append-only:

```text
outputs/mdlm_owt/direct/<decoder_id>/
  manifest.json
  generations/shard_<first>_<last>.jsonl
  evaluations/<evaluator_id>/
    manifest.json
    scores_<first>_<last>.jsonl
    summary.json                 # immutable first summary for legacy readers
    summaries/summary_<N>.json   # append-only snapshots as the run grows
```

Rows have `conditioning_mode: unconditional` and never contain a synthetic
prompt. Resume scans global sample indices, rejects duplicate IDs/indices, and
generates only missing indices up to `target_samples`.

## SMC estimator

For tilted component `j`, reverse-SNIS is normalized separately:

```text
          sum_i W_j,i exp(-lambda_j r(X_j,i)) 1_E(X_j,i)
p_hat_j = -------------------------------------------------
              sum_i W_j,i exp(-lambda_j r(X_j,i))
```

Only after every ratio is formed do we aggregate:

```text
p_hat = sum_j a_j p_hat_j.
```

The generic aggregation function accepts any non-negative simplex vector.
Current configurations select `component_weight_policy: uniform`, requiring
`a_j=1/J`. Smoke profiles use tilted lambdas `[5, 10]` and weights `[0.5,
0.5]` only to exercise the convex-combination code; these values are not
claimed to be optimal.

`lambda=0` is listed under `diagnostic_lambdas`, saved separately, checked
against the unconditional base sampler, and excluded from the final convex
combination. Including it later requires an explicit entry in `tilted_lambdas`
and a corresponding weight.

```bash
python -m diffusion_toxicity_smc_experiment.run_smc \
  --config configs/mdlm_owt_unconditional_smoke_technical.yaml

python -m diffusion_toxicity_smc_experiment.compare \
  --config configs/mdlm_owt_unconditional_smoke_technical.yaml \
  --output-root outputs
```

Component artifacts retain terminal text/tokens, rewards, event scores,
forward and reverse weights, ESS, genealogy, runtime, NFE, and peak CUDA
memory. Reports distinguish tilted components from diagnostic components and
contain no prompt aggregation.
