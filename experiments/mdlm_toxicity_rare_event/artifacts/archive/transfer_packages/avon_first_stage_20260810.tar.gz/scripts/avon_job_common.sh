#!/usr/bin/env bash

set -euo pipefail

avon_activate_environment() {
  : "${SLURM_JOB_ID:?This script must run inside a SLURM allocation}"
  : "${PROJECT_DIR:?Set PROJECT_DIR}"
  : "${VENV_DIR:?Set VENV_DIR}"
  : "${HF_HOME:?Set HF_HOME}"
  : "${AVON_MODULES:?Set AVON_MODULES from the verified module spider output}"

  if ! type module >/dev/null 2>&1; then
    echo "The environment-modules command is unavailable; stop without guessing an initialization path." >&2
    exit 1
  fi
  module purge
  read -r -a avon_module_list <<< "${AVON_MODULES}"
  module load "${avon_module_list[@]}"
  source "${VENV_DIR}/bin/activate"
  cd "${PROJECT_DIR}"

  export HF_HOME
  export HF_HUB_CACHE="${HF_HOME}/hub"
  export TOKENIZERS_PARALLELISM=false
  export PYTHONUNBUFFERED=1
}

avon_print_diagnostics() {
  echo "hostname=$(hostname -f)"
  echo "git_commit=$(git rev-parse HEAD)"
  echo "project_dir=$(pwd -P)"
  echo "hf_home=${HF_HOME}"
  echo "modules=${AVON_MODULES}"
  nvidia-smi
  python - <<'PY'
import json
import platform
import torch

payload = {
    "python": platform.python_version(),
    "torch": torch.__version__,
    "torch_cuda": torch.version.cuda,
    "cuda_available": torch.cuda.is_available(),
}
if torch.cuda.is_available():
    payload.update({
        "gpu": torch.cuda.get_device_name(0),
        "compute_capability": list(torch.cuda.get_device_capability(0)),
        "bf16_supported": bool(torch.cuda.is_bf16_supported()),
    })
print(json.dumps(payload, sort_keys=True))
PY
}

avon_print_cpu_diagnostics() {
  echo "hostname=$(hostname -f)"
  echo "git_commit=$(git rev-parse HEAD)"
  echo "project_dir=$(pwd -P)"
  echo "hf_home=${HF_HOME}"
  echo "modules=${AVON_MODULES}"
  python - <<'PY'
import json
import platform
import torch

print(json.dumps({
    "python": platform.python_version(),
    "torch": torch.__version__,
    "torch_cuda": torch.version.cuda,
    "cuda_available": torch.cuda.is_available(),
}, sort_keys=True))
PY
}
