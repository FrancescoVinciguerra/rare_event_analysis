#!/usr/bin/env bash
#SBATCH --job-name=mdlm-smc
#SBATCH --partition=gpu
#SBATCH --qos=normal
#SBATCH --gres=gpu:quadro_rtx_6000:1
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=20G
#SBATCH --time=2-00:00:00
#SBATCH --output=logs/%x-%j.out
#SBATCH --error=logs/%x-%j.err

set -euo pipefail
source "${PROJECT_DIR:-/gpfs/home/stats/stuhvh/rea_of_llms_supplementary_code}/scripts/avon_job_common.sh"
avon_activate_environment
avon_print_diagnostics
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1

python -m diffusion_toxicity_smc_experiment.run_smc \
  --config "${SMC_CONFIG:-configs/mdlm_owt_unconditional_smc.yaml}" \
  --output-root "${OUTPUT_ROOT:-outputs}"
nvidia-smi --query-gpu=name,memory.used,memory.total --format=csv
