"""GPU population measurement using the scheduled version of the SAME kernel.

Population recording is materialized from camera_ready_gpu.population; only
the kernel call receives the explicit fixed schedule. No models load on import.
"""
import torch
import time
from .camera_ready_gpu import component_config
from .exploratory_kernel import run_scheduled_trajectory_component
from .low_budget import estimates
from .smc import ess_from_log_weights

@torch.inference_mode()
def population(context,config,study,seed):
    c=component_config(config,seed); f=context.functions
    context.synchronize(); started=time.perf_counter()
    result=run_scheduled_trajectory_component(schedule=config['_exploration']['schedule'],sampler=context.sampler,fixed_prefix_token_ids=None,
        reward_fn=f.reward,event_fn=f.event,config=c,device=context.device)
    # Include final transfers and BOTH threshold corrections in the measured estimate.
    log_weights=result.final_log_weights.detach().cpu().tolist()
    rewards=result.rewards.detach().cpu().tolist()
    scores=[float(r['toxic_probability']) for r in f.last_event_rows]
    corrections={str(a):estimates(log_weights,rewards,result.log_normalizer_estimate,
        scores,a,c.lambda_final) for a in study['thresholds']}
    context.synchronize(); elapsed=time.perf_counter()-started
    roots=result.root_ancestors.cpu().tolist(); tokens=result.terminal_tokens.cpu().tolist()
    proposals=sum(int(m['proposals']) for m in result.mutation_diagnostics)
    accepted=sum(int(m['accepted']) for m in result.mutation_diagnostics)
    ddpm=c.num_particles*c.num_steps+sum(int(m['rollback_particle_steps']) for m in result.mutation_diagnostics)
    summary={'num_particles':c.num_particles,'seed':int(seed),'lambda':c.lambda_final,
        'log_normalizer_estimate':result.log_normalizer_estimate,
        'total_decoder_particle_steps':ddpm,'mcmc_proposals':proposals,
        'mcmc_acceptance_rate':accepted/proposals if proposals else 0.,
        'distinct_root_ancestors':len(set(roots)),
        'distinct_terminal_sequences':len({tuple(t) for t in tokens}),
        'final_smc_ess':ess_from_log_weights(result.final_log_weights),
        'runtime_seconds':elapsed,'nfe':result.nfe,
        'resampling_count':len(result.genealogy)}
    return {'summary':summary,'corrections':corrections,
        'particles':[{'root_ancestor':int(roots[i]),'token_ids':tokens[i],
            'reward':rewards[i],'event_toxic_probability':scores[i],
            'final_log_weight':log_weights[i]} for i in range(c.num_particles)],
        'genealogy':result.genealogy,'level_diagnostics':result.level_diagnostics,
        'mutation_diagnostics':result.mutation_diagnostics,
        'timing_includes':'initial generation, score, weights, resampling, rollback, MH, both corrections; excludes model load, warmup and file IO'}
