#!/usr/bin/env bash
set -euo pipefail

mode=${1:---dry-run}
case "$mode" in
  --dry-run|--submit|--resume) ;;
  *) printf 'Usage: %s [--dry-run|--submit|--resume]\n' "$0" >&2; exit 2 ;;
esac

: "${PROJECT_DIR:?Set the repository directory}"
: "${EXPERIMENT_DIR:?Set the unpacked frozen experiment directory}"
: "${OUTPUT_ROOT:?Set the saved artifact directory}"
: "${LOG_DIR:?Set a Slurm log directory}"
: "${VENV_DIR:?Set the existing environment directory}"
: "${HF_HOME:?Set the existing model cache}"
: "${AVON_MODULES:?Set the verified Avon modules}"
export PROJECT_DIR EXPERIMENT_DIR OUTPUT_ROOT LOG_DIR VENV_DIR HF_HOME AVON_MODULES
export RESULT_NAME=camera_ready_paper_final_scaling
export STUDY_CONFIG=mdlm_owt_paper_final_scaling.yaml
export CALIBRATION_ROOT="${CALIBRATION_ROOT:-$OUTPUT_ROOT/camera_ready_same_run_ladder}"
export PAPER_FINAL_REUSE="${PAPER_FINAL_REUSE:-1}"
case "$PAPER_FINAL_REUSE" in
  1) walltime=18:00:00; export SOFT_MAX_SECONDS=63000 ;;
  0) walltime=40:00:00; export SOFT_MAX_SECONDS=140400 ;;
  *) printf 'PAPER_FINAL_REUSE must be 0 or 1.\n' >&2; exit 2 ;;
esac

mkdir -p "$LOG_DIR"
job_name=mdlm-paper-final-scaling
job_script="$EXPERIMENT_DIR/scripts/slurm_avon_particle_scaling.sh"
options=(--no-requeue --account=stats --partition=gpu --qos=normal --nodes=1 --nodelist=gpu007
  --gres=gpu:quadro_rtx_6000:3 --ntasks=3 --cpus-per-task=4 --mem=60G --time="$walltime"
  --job-name="$job_name" --chdir="$PROJECT_DIR" --export=ALL
  --output="$LOG_DIR/%x-%j.out" --error="$LOG_DIR/%x-%j.err")

if [[ "$mode" == --dry-run ]]; then
  printf ' %q' sbatch --test-only "${options[@]}" "$job_script"
  printf '\n'
  sbatch --test-only "${options[@]}" "$job_script"
  exit
fi

root="$OUTPUT_ROOT/$RESULT_NAME"
mkdir -p "$root"
exec 9>"$root/.submission.lock"
flock -n 9
if [[ "$mode" == --submit && -s "$root/latest_submission.txt" ]]; then
  cat "$root/latest_submission.txt"
  exit
fi
if [[ -n "$(squeue -h -u "$USER" -n "$job_name" -o '%i')" ]]; then
  printf 'A submission for %s is already in the queue.\n' "$job_name" >&2
  exit 1
fi
if [[ "$mode" == --resume ]]; then
  test -s "$root/latest_submission.txt"
  if [[ -f "$root/report_status.json" ]] && grep -Eq '"complete": *true' "$root/report_status.json"; then
    printf 'This campaign is complete.\n' >&2
    exit 1
  fi
fi
job=$(sbatch --parsable "${options[@]}" "$job_script")
printf '%s\n' "$job" | tee "$root/latest_submission.txt" | tee -a "$root/submissions.txt"
