"""Render three alternative layouts for the saved q >= .999, lambda = 2.5 comparison."""
from collections import defaultdict
import csv
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np
from scipy.stats import binomtest

ROOT = Path("mdlm/artifacts/current/camera_ready_progressive_tail_particle_scaling/across_budget")
OUT = ROOT / "comparison_designs"
COLORS = {"smc": "#14698f", "crude": "#a44e28"}
LABELS = {"smc": "RollBack-SMC", "crude": "Crude Monte Carlo"}
MARKERS = {"smc": "o", "crude": "s"}
P_REF = 26 / 200_000
REF_CI = binomtest(26, 200_000).proportion_ci(method="wilson")

plt.rcParams.update({
    "text.usetex": True, "font.family": "serif", "font.serif": ["Times"],
    "font.sans-serif": ["Helvetica"], "font.monospace": ["Courier"],
    "font.size": 11, "axes.spines.top": False, "axes.spines.right": False,
    "savefig.dpi": 300,
})


def read(path):
    with path.open(encoding="utf-8", newline="") as file:
        return list(csv.DictReader(file))


def comparison():
    cohorts = defaultdict(list)
    for row in read(ROOT / "across_budget_runs.csv"):
        if float(row["threshold"]) == .999 and float(row["lambda"]) == 2.5:
            cohorts[int(row["N"])].append(row)
    summaries = {(int(r["N"]), r["method"], r["metric"]): r
                 for r in read(ROOT / "across_budget_summary.csv")
                 if float(r["threshold"]) == .999 and float(r["tilt"]) == 2.5 and r["subset"] == "all"}
    rng = np.random.default_rng(2134669)
    result = []
    for n, rows in sorted(cohorts.items()):
        if (len(rows) != 24 or len({r["seed"] for r in rows}) != 24
                or len({r["crude_pool_start"] for r in rows}) != 24
                or len({r["campaign"] for r in rows}) != 1
                or any(r["smc_seconds_measured"] != "True" or float(r["p_reference"]) != P_REF
                       or not np.isclose(float(r["crude"]), int(r["crude_hits"]) / int(r["crude_n"]))
                       for r in rows)):
            raise ValueError(f"Unexpected pairing, reference or provenance for N={n}")
        budget = P_REF * np.mean([int(r["crude_n"]) for r in rows])
        draws = rng.integers(len(rows), size=(20000, len(rows)))
        smc, mc = (np.array([float(r[m]) for r in rows]) for m in COLORS)
        record = {"N": n, "B": budget, "R": len(rows), "campaign": rows[0]["campaign"]}
        for method, values in zip(COLORS, (smc, mc), strict=True):
            for metric, calculated in (
                ("mean_relative_error", np.mean(abs(values / P_REF - 1))),
                ("relative_sd", np.std(values, ddof=1) / P_REF),
            ):
                saved = summaries[n, method, metric]
                if not np.isclose(budget, float(saved["budget"])) or not np.isclose(calculated, float(saved["estimate"])):
                    raise ValueError(f"Saved statistic mismatch: {n}, {method}, {metric}")
                for key in ("estimate", "lower_95", "upper_95"):
                    record[f"{method}_{metric}_{key}"] = float(saved[key])
            record[f"{method}_zeros"] = int(np.count_nonzero(values == 0))
            record[f"{method}_relative_rmse_estimate"] = np.sqrt(np.mean((values / P_REF - 1)**2))
        for label, reference in (("fixed", P_REF), ("low_ref", REF_CI.low), ("high_ref", REF_CI.high)):
            delta = abs(mc / reference - 1) - abs(smc / reference - 1)
            record[f"delta_{label}_estimate"] = delta.mean()
            lo, hi = np.quantile(delta[draws].mean(axis=1), [.025, .975])
            record[f"delta_{label}_lower_95"] = lo
            record[f"delta_{label}_upper_95"] = hi
        result.append(record)
    return result


def marks(ax, data, field, *, method=None, intervals=False):
    x = np.array([row["B"] for row in data])
    y = np.array([row[field + "_estimate"] for row in data])
    color = COLORS[method] if method else "#414957"
    line, = ax.plot(x, y, color=color, marker=MARKERS[method] if method else "o",
                    markersize=4.4, lw=1.55, label=LABELS.get(method))
    if intervals:
        lo, hi = (np.array([row[field + "_" + k] for row in data]) for k in ("lower_95", "upper_95"))
        ax.vlines(x, lo, hi, color=color, lw=.95, alpha=.85, zorder=2)
        for bound in (lo, hi):
            ax.plot(x, bound, linestyle="none", marker="_", markersize=5, color=color, alpha=.85, zorder=2)
    return line


def methods(ax, data, metric, *, intervals=False):
    return [marks(ax, data, f"{m}_{metric}", method=m, intervals=intervals) for m in COLORS]


def panel(ax, title, ylabel):
    ax.set_title(title, loc="left", fontweight="bold", fontsize=12, pad=7)
    ax.set_ylabel(ylabel)
    ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
    ax.grid(axis="y", color="#e5e8ec", linewidth=.7)
    ax.set_axisbelow(True)
    ax.tick_params(length=3, color="#686b71")
    ax.set_xlim(.065, .825)


def heading(fig, title, subtitle):
    fig.text(.12, .965, r"\textbf{" + title + "}", fontsize=19, va="top")
    fig.text(.12, .908 if len(fig.axes) == 1 else .919, subtitle, fontsize=11, va="top")


def footer(fig, line, detail):
    fig.text(.12, .067, line, fontsize=9)
    fig.text(.12, .035, detail, fontsize=9)


def save(fig, name):
    for extension in ("pdf", "png"):
        fig.savefig(OUT / f"{name}.{extension}", facecolor="white")
    plt.close(fig)


def render(data):
    setup = r"$q\geq0.999$, $\lambda=2.5$, 24 runs per budget"
    reference = r"$p_{\mathrm{ref}}=1.30\times10^{-4}$ (26/200,000; 95\% Wilson CI $[0.887,1.90]\times10^{-4}$)."
    budget_label = r"Normalized budget $B=\overline{N}_{\mathrm{MC,equiv}}p_{\mathrm{ref}}$"
    fixed = r"Bars: pointwise 95\% bootstrap CIs conditional on $p_{\mathrm{ref}}$."
    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    fig.subplots_adjust(left=.12, right=.96, top=.79, bottom=.22)
    heading(fig, "Accuracy at matched compute", setup + r"; $B=1$ corresponds to one expected MC event.")
    lines = methods(ax, data, "mean_relative_error", intervals=True)
    panel(ax, "", "Mean absolute relative error")
    ax.axhline(1, color="#777777", linestyle=":", lw=1, zorder=1)
    ax.set_ylim(bottom=0)
    ax.set_xlabel(budget_label)
    ax.legend(handles=lines, loc="upper left", ncols=2, frameon=False)
    footer(fig, fixed + r" Dotted line: error of a zero estimate.", reference)
    save(fig, "A_accuracy")

    fig, (ax, sd, zero) = plt.subplots(3, 1, sharex=True, figsize=(7.5, 8.1))
    fig.subplots_adjust(left=.12, right=.96, top=.825, bottom=.145, hspace=.52)
    heading(fig, "Accuracy, variability and reliability", setup)
    lines = methods(ax, data, "mean_relative_error", intervals=True)
    methods(sd, data, "relative_sd", intervals=True)
    for method in COLORS:
        zero.plot([r["B"] for r in data], [r[f"{method}_zeros"] / r["R"] for r in data],
                  color=COLORS[method], marker=MARKERS[method], markersize=4.4, lw=1.55)
    for axis, title, label in ((ax, "A  Accuracy", "Mean absolute relative error"),
                               (sd, "B  Variability", r"$s(\widehat p)/p_{\mathrm{ref}}$"),
                               (zero, "C  Reliability", "Zero estimates")):
        panel(axis, title, label)
        axis.set_ylim(bottom=0)
    ax.axhline(1, color="#777777", linestyle=":", lw=1, zorder=1)
    zero.set_ylim(-.02, 1.03)
    zero.set_yticks([0, .25, .5, .75, 1])
    zero.set_xlabel(budget_label)
    fig.legend(handles=lines, ncols=2, loc="upper left", bbox_to_anchor=(.11, .895), frameon=False)
    footer(fig, fixed + r" Panel C uses all 24 runs per method.", reference)
    save(fig, "B_accuracy_variability_reliability")

    fig, (ax, delta) = plt.subplots(2, 1, sharex=True, figsize=(7.5, 6.6))
    fig.subplots_adjust(left=.12, right=.96, top=.80, bottom=.17, hspace=.53)
    heading(fig, "Which method is more accurate?", setup)
    lines = methods(ax, data, "relative_rmse")
    marks(delta, data, "delta_fixed", intervals=True)
    panel(ax, "A  Relative RMSE", r"$\mathrm{RMSE}/p_{\mathrm{ref}}$")
    panel(delta, "B  Paired absolute relative error difference", r"$\overline{\Delta}$ (MC $-$ SMC)")
    ax.set_ylim(bottom=0)
    delta.axhline(0, color="#777777", linestyle=":", lw=1)
    delta.set_xlabel(budget_label)
    fig.legend(handles=lines, ncols=2, loc="upper left", bbox_to_anchor=(.11, .89), frameon=False)
    footer(fig, r"Positive $\overline{\Delta}$ favors SMC. Bars: paired 95\% bootstrap CIs at fixed $p_{\mathrm{ref}}$.",
           reference)
    save(fig, "C_compute_efficiency")


if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    data = comparison()
    with (OUT / "figure_data_and_reference_sensitivity.csv").open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(data[0]))
        writer.writeheader()
        writer.writerows(data)
    with (OUT / "zero_counts.csv").open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["N", "B", "R", "smc_zeros", "crude_zeros"],
                                extrasaction="ignore")
        writer.writeheader()
        writer.writerows(data)
    render(data)
