"""Export single-axis paper figures without changing the saved MDLM comparison."""
from collections import defaultdict
import csv
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, PercentFormatter
import numpy as np
from scipy.stats import binomtest

ROOT = Path("mdlm/artifacts/current/camera_ready_progressive_tail_particle_scaling/across_budget")
OUT = ROOT / "publication_figures"
METHODS = (("smc", "RollBack-SMC", "#14698f", "o"), ("crude", "Crude MC", "#a44e28", "s"))
METRICS = {
    "mean_relative_error": ("Mean absolute relative error", "Mean absolute relative error"),
    "relative_rmse": ("Relative RMSE", r"$\mathrm{RMSE}/p_{\mathrm{ref}}$"),
    "relative_sd": ("Relative standard deviation", r"$s(\widehat p)/p_{\mathrm{ref}}$"),
    "zero_rate": ("Zero-estimate rate", "Zero estimates"),
    "within_factor_ten": ("Within a factor of ten", "Estimates within a factor of ten"),
    "mean_ratio": ("Mean estimate / reference", r"$\mathrm{mean}(\widehat p)/p_{\mathrm{ref}}$"),
    "median_ratio": ("Median estimate / reference", r"$\mathrm{median}(\widehat p)/p_{\mathrm{ref}}$"),
    "median_relative_error": ("Median absolute relative error", "Median absolute relative error"),
    "paired_difference": ("Paired error difference", r"$\overline{\Delta}$ (MC $-$ SMC)"),
}
REFERENCE_COUNTS = {.99: (444, 200000), .995: (334, 298800), .999: (26, 200000), .9995: (10, 975775)}
STYLE = {
    "text.usetex": True, "font.family": "serif", "font.serif": ["Times"],
    "font.sans-serif": ["Helvetica"], "font.monospace": ["Courier"],
    "font.size": 10, "axes.labelsize": 10, "axes.titlesize": 11,
    "legend.fontsize": 9, "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": .65, "axes.grid": True, "axes.grid.axis": "y",
    "axes.axisbelow": True, "grid.color": "#e5e8ec", "grid.linewidth": .6,
    "figure.facecolor": "white", "axes.facecolor": "white", "savefig.dpi": 320,
    "lines.linewidth": 1.45, "lines.markersize": 4.1,
}


def read(path):
    with path.open(encoding="utf-8", newline="") as file:
        return list(csv.DictReader(file))


def collect():
    runs = defaultdict(list)
    for row in read(ROOT / "across_budget_runs.csv"):
        key = (float(row["threshold"]), float(row["lambda"]), int(row["N"]))
        runs[key].append(row)
    summaries = defaultdict(list)
    for row in read(ROOT / "across_budget_summary.csv"):
        key = (float(row["threshold"]), float(row["tilt"]), row["subset"], row["metric"])
        summaries[key].append(dict(row, N=int(row["N"]), budget=float(row["budget"]),
                                   estimate=float(row["estimate"]) if row["estimate"] else np.nan,
                                   lower=float(row["lower_95"]) if row["lower_95"] else np.nan,
                                   upper=float(row["upper_95"]) if row["upper_95"] else np.nan))
    previous = {int(r["N"]): r for r in read(ROOT / "comparison_designs/figure_data_and_reference_sensitivity.csv")}
    rng = np.random.default_rng(2134669)
    for (threshold, tilt, n), rows in sorted(runs.items()):
        hits, total = REFERENCE_COUNTS[threshold]
        reference = hits / total
        budget = np.mean([int(r["crude_n"]) for r in rows]) * reference
        if len({int(r["seed"]) for r in rows}) != len(rows) or any(
            not np.isclose(float(r["p_reference"]), reference, rtol=1e-12, atol=0) for r in rows
        ):
            raise ValueError(f"Unexpected reference or duplicate seed at {(threshold, tilt, n)}")
        draws = rng.integers(len(rows), size=(20000, len(rows)))
        for method, *_ in METHODS:
            estimates = np.array([float(r[method]) for r in rows])
            ratios = estimates / reference
            squared_errors = (ratios - 1)**2
            rmse = np.sqrt(squared_errors.mean())
            if threshold == .999 and tilt == 2.5:
                np.testing.assert_allclose(rmse, float(previous[n][f"{method}_relative_rmse_estimate"]),
                                           rtol=1e-12, atol=0)
            lo, hi = np.quantile(np.sqrt(squared_errors[draws].mean(axis=1)), [.025, .975])
            for metric, value, lower, upper in (
                ("relative_rmse", rmse, lo, hi),
                ("zero_rate", np.mean(estimates == 0), np.nan, np.nan),
                ("within_factor_ten", np.mean((ratios >= .1) & (ratios <= 10)), np.nan, np.nan),
            ):
                summaries[threshold, tilt, "all", metric].append(dict(
                    N=n, method=method, budget=budget, estimate=value, lower=lower, upper=upper))
            for subset, values in (("all", ratios), ("positive", ratios[ratios > 0])):
                for metric, function, minimum in (
                    ("mean_ratio", np.mean, 1), ("median_ratio", np.median, 1),
                    ("relative_sd", lambda x: np.std(x, ddof=1), 2),
                    ("mean_relative_error", lambda x: np.mean(abs(x - 1)), 1),
                    ("median_relative_error", lambda x: np.median(abs(x - 1)), 1),
                ):
                    saved, = (r for r in summaries[threshold, tilt, subset, metric]
                              if r["method"] == method and r["N"] == n)
                    expected = function(values) if len(values) >= minimum else np.nan
                    np.testing.assert_allclose(saved["estimate"], expected, rtol=1e-11, atol=1e-15)
                    np.testing.assert_allclose(saved["budget"], budget, rtol=1e-12)
                    if int(saved["zeros"]) != np.count_nonzero(estimates == 0) or int(saved["runs"]) != len(rows):
                        raise ValueError(f"Saved counts differ at {(threshold, tilt, n, method)}")
        if threshold == .999 and tilt == 2.5:
            paired = previous[n]
            np.testing.assert_allclose(float(paired["B"]), budget, rtol=1e-12)
            summaries[threshold, tilt, "all", "paired_difference"].append(dict(
                N=n, method="paired", budget=budget, estimate=float(paired["delta_fixed_estimate"]),
                lower=float(paired["delta_fixed_lower_95"]), upper=float(paired["delta_fixed_upper_95"])))
    return runs, summaries


def plot(rows, metric):
    title, ylabel = METRICS[metric]
    fig, ax = plt.subplots(figsize=(5.4, 3.45))
    fig.subplots_adjust(left=.17, right=.973, bottom=.195, top=.78)
    methods = METHODS if metric != "paired_difference" else (("paired", "", "#414957", "o"),)
    upper_limit = 0
    for method, label, color, marker in methods:
        series = sorted((r for r in rows if r["method"] == method), key=lambda r: r["budget"])
        x, y, lo, hi = np.array([[r[k] for k in ("budget", "estimate", "lower", "upper")]
                                for r in series]).T
        ax.plot(x, y, color=color, marker=marker, label=label)
        interval = np.isfinite(lo) & np.isfinite(hi)
        ax.vlines(x[interval], lo[interval], hi[interval], color=color, lw=.85, alpha=.9)
        for end in (lo, hi):
            ax.plot(x[interval], end[interval], linestyle="none", marker="_", markersize=4,
                    markeredgewidth=.85, color=color)
        finite = np.r_[y[np.isfinite(y)], hi[interval]]
        upper_limit = max(upper_limit, finite.max(initial=0))
    if metric in {"mean_relative_error", "median_relative_error", "mean_ratio", "median_ratio"}:
        ax.axhline(1, color="#777777", linestyle=":", linewidth=.85)
    if metric == "paired_difference":
        ax.axhline(0, color="#777777", linestyle=":", linewidth=.85)
    elif metric in {"zero_rate", "within_factor_ten"}:
        ax.set_ylim(-.03, 1.05)
        ax.set_yticks([0, .25, .5, .75, 1])
    else:
        if upper_limit > 8:
            ax.set_yscale("symlog", linthresh=.1)
            ax.set_ylim(bottom=-.008)
        else:
            ax.set_ylim(bottom=-.018 * max(upper_limit, 1))
    ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
    ax.xaxis.set_major_locator(MaxNLocator(nbins=5, min_n_ticks=4))
    ax.set_xlabel("Expected MC events at equal compute")
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="both", width=.65, length=3)
    ax.minorticks_off()
    fig.text(.17, .955, r"\textbf{" + title + "}", va="top", fontsize=12)
    if metric != "paired_difference":
        handles, labels = ax.get_legend_handles_labels()
        fig.legend(handles, labels, loc="upper left", bbox_to_anchor=(.157, .895),
                   ncols=2, frameon=False)
    assert len(fig.axes) == 1
    return fig, ax.get_yscale()


def caption_for(threshold, tilt, subset, metric, cohorts, scale):
    hits, samples = REFERENCE_COUNTS[threshold]
    ref = binomtest(hits, samples).proportion_ci(method="wilson")
    count = ", ".join(f"N={n}: {len(rows)}" for n, rows in cohorts)
    caption = (f"Threshold q ≥ {threshold:g}, tilt λ = {tilt:g}. "
               f"Budget B = mean(N_MC,equiv) × p_ref; B = 1 is one expected crude MC event. "
               f"p_ref = {hits}/{samples:,} = {hits/samples:.5g} "
               f"(95% Wilson CI [{ref.low:.4g}, {ref.high:.4g}]). Replicates per method: {count}. ")
    if subset == "positive":
        caption += ("Conditional on a positive estimate separately for each method. "
                    "The accompanying counts table gives the number retained. ")
    else:
        caption += "All estimates, including zeros, contribute. "
    if metric == "relative_sd":
        caption += "The statistic is the sample standard deviation across runs divided by p_ref. "
    elif metric == "relative_rmse":
        caption += "RMSE is the square root of the mean squared error across runs, divided by p_ref. "
    elif metric == "paired_difference":
        caption += "Each pair is one SMC estimate and its matched-cost MC estimate. Positive differences favor SMC. "
    elif metric == "within_factor_ten":
        caption += "Success means the estimate is between 0.1 and 10 times p_ref, inclusive. "
    if metric not in {"zero_rate", "within_factor_ten"}:
        caption += "Bars are pointwise 95% percentile bootstrap intervals at fixed p_ref (20,000 resamples). "
        if metric == "paired_difference":
            caption += "Each bootstrap draw resamples complete pairs. "
    if metric in {"mean_relative_error", "median_relative_error"}:
        caption += "The dotted 100% line is the absolute relative error of a zero estimate. "
    elif metric in {"mean_ratio", "median_ratio"}:
        caption += "The dotted 100% line denotes agreement with the reference. "
    if scale == "symlog":
        caption += "The vertical scale is linear near zero and logarithmic at large values. "
    return caption


def main():
    runs, summaries = collect()
    OUT.mkdir(exist_ok=True)
    captions = ["# Publication figures", "",
                "Budgets are placed at their numeric values. MC costs are calibrated wall-clock equivalents. "
                "Some historical checkpoints for q ≥ 0.99 and q ≥ 0.995 have reconstructed SMC times. "
                "Saved MC prefixes can be shared across configurations, so intervals are pointwise. "
                "The pooled q ≥ 0.9995 reference includes the matched MC pool. "
                "Reference uncertainty is reported separately from bootstrap uncertainty.", ""]
    with plt.rc_context(STYLE):
        for (threshold, tilt, subset, metric), rows in sorted(summaries.items()):
            tag = f"q{threshold:g}_lambda{tilt:g}".replace(".", "p")
            folder = OUT / tag
            folder.mkdir(exist_ok=True)
            stem = metric + ("_positive" if subset == "positive" else "")
            cohorts = [(n, group) for (q, lam, n), group in sorted(runs.items()) if (q, lam) == (threshold, tilt)]
            fig, scale = plot(rows, metric)
            caption = caption_for(threshold, tilt, subset, metric, cohorts, scale)
            fig.savefig(folder / f"{stem}.pdf", metadata={"Title": METRICS[metric][0], "Subject": caption})
            fig.savefig(folder / f"{stem}.png", metadata={"Title": METRICS[metric][0], "Description": caption})
            plt.close(fig)
            captions.extend([f"### {tag} / {stem}", "", caption, ""])
    (OUT / "captions.md").write_text("\n".join(captions), encoding="utf-8")
    with (OUT / "replicate_counts.csv").open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["threshold", "tilt", "N", "campaign", "method", "runs", "zeros", "positive",
                         "smc_seconds_measured"])
        for (threshold, tilt, n), rows in sorted(runs.items()):
            for method, *_ in METHODS:
                zeros = sum(float(r[method]) == 0 for r in rows)
                writer.writerow([threshold, tilt, n, rows[0]["campaign"], method, len(rows), zeros,
                                 len(rows) - zeros, rows[0]["smc_seconds_measured"]])
    print(f"Exported {len(summaries)} single-axis figures in both PDF and PNG.")


if __name__ == "__main__":
    main()
