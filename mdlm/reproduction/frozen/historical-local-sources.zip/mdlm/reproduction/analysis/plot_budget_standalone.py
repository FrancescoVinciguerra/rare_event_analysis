"""Export standalone figures from the four-threshold across-budget summary."""
import argparse
import csv
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter
import numpy as np


plt.rcParams.update({
    "text.usetex": True,
    "font.family": "serif",
    "font.serif": ["Times"],
    "font.sans-serif": ["Helvetica"],
    "font.monospace": ["Courier"],
})

METHODS = (("smc", "RollBack–SMC", "#14698f", "o"), ("crude", "MC diretto", "#a44e28", "s"))
METRICS = (
    ("errore", "Errore relativo assoluto", r"$|\widehat p-p_{\mathrm{rif}}|/p_{\mathrm{rif}}$",
     ("mean_relative_error", "median_relative_error")),
    ("rapporto", "Rapporto stima / riferimento", r"$\widehat p/p_{\mathrm{rif}}$",
     ("mean_ratio", "median_ratio")),
    ("dispersione", "Deviazione standard relativa", r"$s(\widehat p)/p_{\mathrm{rif}}$",
     ("relative_sd",)),
)


def panel(rows, output, threshold, subset, specification, *, zoom=False):
    stem, title, formula, metrics = specification
    tilt, = {float(r["tilt"]) for r in rows}
    selected = {(int(r["N"]), r["method"], r["metric"]): r for r in rows if r["subset"] == subset}
    sizes = sorted({n for n, _, _ in selected})
    base_x = np.arange(len(sizes))
    fig, ax = plt.subplots(figsize=(10.3, 5.9))
    extrema = []
    for (method, _, color, marker), offset in zip(METHODS, (-.09, .09), strict=True):
        for index, metric in enumerate(metrics):
            series = [selected[n, method, metric] for n in sizes]
            x = base_x + offset
            y, lower, upper = np.array([
                [float(r[k]) if r[k] else np.nan for k in ("estimate", "lower_95", "upper_95")]
                for r in series
            ]).T
            valid = np.isfinite(y)
            ax.plot(x[valid], y[valid], "-" if index == 0 else "--", color=color, marker=marker,
                    markerfacecolor=color if index == 0 else "white", markersize=6, lw=1.8)
            extrema.extend(y[valid])
            if index == 0:
                interval = np.isfinite(lower) & np.isfinite(upper)
                centers = x[interval]
                ax.vlines(centers, lower[interval], upper[interval], color=color, lw=1.3, alpha=.8)
                for limits in (lower, upper):
                    ax.hlines(limits[interval], centers - .075, centers + .075, color=color, lw=1.3, alpha=.8)
                extrema.extend(upper[interval])

    handles = [Line2D([], [], color=color, marker=marker, label=label) for _, label, color, marker in METHODS]
    if len(metrics) == 2:
        handles.extend([
            Line2D([], [], color="#454545", label="Media"),
            Line2D([], [], color="#454545", linestyle="--", label="Mediana"),
        ])
    if stem != "dispersione":
        ax.axhline(1, color="#707070", linestyle=":", lw=1.4, zorder=0)
        label = "Errore di una stima nulla" if stem == "errore" else "Probabilità di riferimento"
        handles.append(Line2D([], [], color="#707070", linestyle=":", label=label))

    labels = []
    for n in sizes:
        smc, crude = (selected[n, method, metrics[0]] for method, *_ in METHODS)
        budget = f"{float(smc['budget']):.2g}".replace(".", ",")
        labels.append(f"{budget}\n{smc['zeros']}/{crude['zeros']}/{smc['runs']}")
    ax.set_xticks(base_x, labels, fontsize=11)
    ax.set_xlabel("Budget equivalente (eventi MC attesi)\nZeri SMC / zeri MC / repliche per metodo", fontsize=12)
    ax.set_ylabel(title, fontsize=13)
    ax.tick_params(axis="y", labelsize=11)
    ax.set_xlim(-.44, len(sizes) - .56)
    if zoom:
        ax.set_ylim(0, 2)
    elif max(extrema, default=0) > 4 or (stem == "rapporto" and threshold >= .999):
        ax.set_yscale("symlog", linthresh=.01 if stem == "rapporto" else .1)
        ax.set_ylim(bottom=0)
        ax.text(.985, .96, "Scala simmetrica logaritmica", ha="right", va="top",
                fontsize=10, transform=ax.transAxes)
    else:
        ax.set_ylim(bottom=0)
    ax.yaxis.set_major_formatter(PercentFormatter(xmax=1))
    ax.minorticks_off()
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", alpha=.23)

    heading = "Tutte le repliche" if subset == "all" else "Sole stime positive"
    threshold_label = f"{threshold:g}".replace(".", ",")
    fig.suptitle(rf"\textbf{{{title}}} \enspace $q \geq {threshold_label.replace(',', '{,}')}$"
                 + (r" \enspace \textbf{Zoom}" if zoom else ""),
                 x=.103, y=.98, ha="left", fontsize=21, fontweight="bold")
    tilt_label = f"{tilt:g}".replace(".", "{,}")
    fig.text(.103, .905, rf"{formula} \enspace {heading} \enspace $\lambda = {tilt_label}$", fontsize=14)
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5, .10), ncol=len(handles),
               fontsize=10, frameon=False, columnspacing=1.3)
    interval_label = "sulla media" if len(metrics) == 2 else "sulla deviazione standard"
    fig.text(.5, .076, rf"Barre: IC bootstrap puntuali al 95\% {interval_label}. "
             "Punti equidistanti per leggibilità.", ha="center", fontsize=10)
    note = "MC abbinato al tempo equivalente di SMC per replica."
    if zoom:
        note += r" Scala verticale da 0\% a 200\%."
    fig.text(.5, .039, note, ha="center", fontsize=10)
    fig.subplots_adjust(left=.103, right=.98, top=.835, bottom=.335)
    tag = threshold_label.replace(",", "")
    if threshold == .9995:
        tag += f"_tilt{tilt:g}".replace(".", "p")
    name = f"{tag}_{stem}_{'tutte' if subset == 'all' else 'positive'}" + ("_zoom" if zoom else "")
    fig.savefig(output / f"{name}.png", dpi=180)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("summary", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    with args.summary.open(encoding="utf-8", newline="") as file:
        rows = list(csv.DictReader(file))
    for threshold in sorted({float(r["threshold"]) for r in rows}):
        event = [r for r in rows if float(r["threshold"]) == threshold]
        for tilt in sorted({float(r["tilt"]) for r in event}):
            cohort = [r for r in event if float(r["tilt"]) == tilt]
            for spec in METRICS:
                for subset in ("all", "positive"):
                    panel(cohort, args.output, threshold, subset, spec)
            if threshold == .9995:
                panel(cohort, args.output, threshold, "all", METRICS[0], zoom=True)
    with (args.output / "repliche_e_zeri.csv").open("w", encoding="utf-8", newline="") as file:
        fields = ("threshold", "N", "source_tilts", "budget", "seconds", "p_reference", "method", "zeros", "runs")
        writer = csv.DictWriter(file, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(r for r in rows if r["subset"] == "all" and r["metric"] == "mean_ratio")


if __name__ == "__main__":
    main()
