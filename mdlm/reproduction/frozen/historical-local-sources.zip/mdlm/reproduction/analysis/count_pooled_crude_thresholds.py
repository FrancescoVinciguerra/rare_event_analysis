"""Count the four thresholds on the audited 975,775-sample crude pool."""
import argparse
import hashlib
import json
from pathlib import Path
import re

import numpy as np
from scipy.stats import binomtest

from diffusion_toxicity_smc_experiment.accuracy_budget import study_configs
from diffusion_toxicity_smc_experiment.crude_tail_reference import validated_scores
from diffusion_toxicity_smc_experiment.particle_scaling import validated_pool


THRESHOLDS = (0.99, 0.995, 0.999, 0.9995)
ROOT = Path("mdlm/artifacts/current")


def digest(value):
    return hashlib.sha256(value).hexdigest()


def count_local(seed_audit):
    archived = json.loads((ROOT / "camera_ready_low_particle_budget/pooled_reference_q09995.json").read_bytes())
    old_cohorts = {row["name"]: row for row in archived["cohorts"]}
    original = old_cohorts["original_direct"]
    seeds = set(map(int, re.findall(r"^ORIGINAL_SEED=(\d+)$", seed_audit.read_text(encoding="utf-8"), re.M)))
    assert len(seeds) == original["seed_streams"]
    assert digest("\n".join(map(str, sorted(seeds))).encode()) == original["seed_inventory_sha256"]

    study, _ = study_configs(Path("mdlm/configs/mdlm_owt_progressive_tail_particle_scaling.yaml"))
    assert all(study["reference"][key] == archived[key] for key in ("decoder_id", "evaluator_id"))
    pool, sources = validated_pool(ROOT, study)
    cohorts = {}
    start = 0
    for name in (study["mc_pool"], study["mc_pool_additional"]):
        meta = old_cohorts[name]
        files = [row for row in sources if row["pool"] == name]
        size = sum(row["samples"] for row in files)
        scores = pool[start:start + size]
        assert len(scores) == size == meta["samples"]
        assert digest(scores.astype("<f8", copy=False).tobytes()) == meta["scores_sha256"]
        batch_seeds = {row["seed"] for row in files}
        assert len(batch_seeds) == len(files) == meta["seed_streams"] and not seeds & batch_seeds
        seeds.update(batch_seeds)
        start += size
        cohorts[name] = dict(samples=size, hits=[int(np.count_nonzero(scores >= t)) for t in THRESHOLDS])
    assert start == len(pool)

    fresh = ROOT / "camera_ready_crude_tail_reference"
    manifest = json.loads((fresh / "manifest.json").read_bytes())
    status = json.loads((fresh / "report_status.json").read_bytes())
    assert status["complete"] and all(manifest[key] == archived[key] for key in ("decoder_id", "evaluator_id"))
    hits = np.zeros(len(THRESHOLDS), dtype=int)
    total = batches = 0
    for worker, planned in enumerate(manifest["planned_batches"]):
        for seed, size in planned:
            assert seed not in seeds
            seeds.add(seed)
            path = fresh / "workers" / f"worker_{worker}" / "baselines" / f"seed{seed}.json"
            scores = validated_scores(json.loads(path.read_bytes()), seed, size)
            hits += [np.count_nonzero(scores >= t) for t in THRESHOLDS]
            total += len(scores)
            batches += 1
    assert total == old_cohorts[fresh.name]["samples"]
    assert batches == status["completed_runs"] == old_cohorts[fresh.name]["seed_streams"]
    cohorts[fresh.name] = dict(samples=total, hits=hits.tolist())
    for name, row in cohorts.items():
        assert row["hits"][-1] == old_cohorts[name]["hits"]
    assert len(seeds) == archived["distinct_seed_streams"]
    return archived, cohorts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("seed_audit", type=Path)
    parser.add_argument("--direct-counts", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    archived, cohorts = count_local(args.seed_audit)
    print(f"Thresholds: {THRESHOLDS}. Verified saved cohorts: {cohorts}", flush=True)
    if args.direct_counts is None:
        return
    direct = {float(t): (int(hits), int(total)) for t, hits, total in
              re.findall(r"^DIRECT_COUNT ([\d.]+) (\d+) (\d+)$", args.direct_counts.read_text(encoding="utf-8"), re.M)}
    assert set(direct) == set(THRESHOLDS)
    assert all(total == 200000 for _, total in direct.values())
    assert [direct[q][0] for q in (0.99, 0.999, 0.9995)] == [444, 26, 2]
    cohorts = {"original_direct": dict(samples=200000, hits=[direct[q][0] for q in THRESHOLDS]), **cohorts}
    samples = sum(row["samples"] for row in cohorts.values())
    assert samples == archived["samples"] == 975775
    references = []
    for i, threshold in enumerate(THRESHOLDS):
        hits = sum(row["hits"][i] for row in cohorts.values())
        ci = binomtest(hits, samples).proportion_ci(method="wilson")
        references.append(dict(threshold=threshold, hits=hits, samples=samples,
                               p_reference=hits / samples, wilson_95=[ci.low, ci.high]))
    assert [row["hits"] for row in references[-2:]] == [113, 10]
    result = dict(
        decoder_id=archived["decoder_id"], evaluator_id=archived["evaluator_id"],
        distinct_seed_streams=archived["distinct_seed_streams"], includes_matched_crude_pool=True,
        thresholds=THRESHOLDS, cohorts=cohorts, references=references,
    )
    print(json.dumps(result, indent=2))
    if args.output:
        with args.output.open("x", encoding="utf-8") as file:
            json.dump(result, file, indent=2)
            file.write("\n")


if __name__ == "__main__":
    main()
