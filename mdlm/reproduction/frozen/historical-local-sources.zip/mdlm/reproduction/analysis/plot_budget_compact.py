"""Render two compact comparisons from the saved across-budget replicate table."""
import argparse
from collections import defaultdict
import csv
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter
import numpy as np


METHODS = (("smc", "RollBack–SMC", "#14698f", "o"), ("crude", "MC diretto", "#a44e28", "s"))


def plot(groups, output, *, success):
    fig, axes = plt.subplots(2, 2, figsize=(10.5, 8))
    for (threshold, cohorts), ax in zip(sorted(groups.items()), axes.flat, strict=True):
        sizes = sorted(cohorts)
        budgets = []
        for n in sizes:
            rows = cohorts[n]
            reference = float(rows[0]["p_reference"])
            budgets.append(np.mean([int(row["crude_n"]) for row in rows]) * reference)
        tilts = np.array([tilt for tilt, _ in sizes])
        for method, _, color, marker in METHODS:
            values = []
            for n in sizes:
                rows = cohorts[n]
                ratios = np.array([float(row[method]) / float(row["p_reference"]) for row in rows])
                values.append(np.mean((ratios >= .1) & (ratios <= 10)) if success
                              else np.mean(abs(ratios - 1)))
            for tilt in np.unique(tilts):
                mask = tilts == tilt
                ax.plot(np.flatnonzero(mask), np.array(values)[mask], color=color,
                        marker=marker, markersize=4, lw=2)
        ax.set_title(f"q ≥ {threshold:g}".replace(".", ","), loc="left", fontweight="bold")
        ax.set_xticks(range(len(sizes)), [f"{b:.2g}".replace(".", ",") for b in budgets], fontsize=8)
        ax.set_xlabel("Budget B (eventi MC attesi)", fontsize=9)
        ax.grid(axis="y", alpha=.25)
        ax.spines[["top", "right"]].set_visible(False)
        if success:
            ax.set_ylim(-.025, 1.045)
            ax.set_yticks([0, .25, .5, .75, 1])
        else:
            ax.axhline(1, color="#666666", linestyle=":", lw=1.3)
            if threshold == .9995:
                ax.set_yscale("log")
                ax.set_yticks([1, 2, 4, 6])
                ax.set_ylim(.78, 7.3)
                ax.text(.99, .96, "Scala log", ha="right", va="top", transform=ax.transAxes, fontsize=8)
            else:
                ax.set_ylim(0, 2.2)
                ax.set_yticks([0, .5, 1, 1.5, 2])
        ax.yaxis.set_major_formatter(PercentFormatter(xmax=1, decimals=0))
        ax.minorticks_off()
    title = "Quanto spesso la stima centra l’ordine di grandezza?" if success else "Quanto è grande l’errore medio?"
    definition = ("Quota di repliche entro un fattore 10 dalla probabilità di riferimento"
                  if success else "Differenza assoluta dalla probabilità di riferimento, in percentuale")
    fig.suptitle(title, x=.075, y=.982, ha="left", fontsize=19, fontweight="bold")
    fig.text(.075, .922, definition, fontsize=12)
    handles = [Line2D([], [], color=color, marker=marker, label=label) for _, label, color, marker in METHODS]
    if not success:
        handles.append(Line2D([], [], color="#666666", linestyle=":", label="Errore di una stima nulla"))
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5, .083), ncol=len(handles), frameon=False)
    fig.text(.5, .063, "MC abbinato al costo SMC per replica. Zeri inclusi. Punti equidistanti per leggibilità.",
             ha="center", fontsize=9)
    fig.text(.5, .038, "Per q ≥ 0,9995: prima serie λ = 2,5 (24 repliche); seconda serie λ = 6,5 "
             "(12 repliche a N = 256, 24 per le altre taglie).", ha="center", fontsize=8.5)
    fig.subplots_adjust(left=.075, right=.985, top=.862, bottom=.19, hspace=.52, wspace=.22)
    fig.savefig(output, dpi=180, bbox_inches="tight", pad_inches=.22)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", type=Path)
    args = parser.parse_args()
    groups = defaultdict(lambda: defaultdict(list))
    with args.runs.open(encoding="utf-8", newline="") as file:
        for row in csv.DictReader(file):
            groups[float(row["threshold"])][float(row["lambda"]), int(row["N"])].append(row)
    plot(groups, args.runs.parent / "MDLM_ordine_di_grandezza.png", success=True)
    plot(groups, args.runs.parent / "MDLM_errore_relativo_medio.png", success=False)


if __name__ == "__main__":
    main()
