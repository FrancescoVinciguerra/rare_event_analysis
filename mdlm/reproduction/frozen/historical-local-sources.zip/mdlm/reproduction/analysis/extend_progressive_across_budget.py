"""Reanalyse Avon 2134669 checkpoints at the four fixed event/tilt pairs."""
from __future__ import annotations

import argparse
import csv
import json
import math
from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter
import numpy as np

from diffusion_toxicity_smc_experiment.accuracy_budget import study_configs
from diffusion_toxicity_smc_experiment.particle_scaling import (
    checkpoint_log_estimates, validated_pool,
)
from diffusion_toxicity_smc_experiment.same_run_reuse import (
    fixed_mc_block, native_clock_count, write_csv,
)

TILTS = {0.99: 0.5, 0.995: 1.0, 0.999: 2.5, 0.9995: 6.5}
SIZES = (320, 384, 448, 512)
METHODS = (("smc", "RollBack–SMC", "#17678c"), ("crude", "Monte Carlo diretto", "#64676e"))
FIELDS = (
    "campaign", "N", "seed", "replicate", "lambda", "threshold", "p_reference",
    "smc_seconds", "smc_seconds_measured", "smc_native_transitions",
    "crude_pool_start", "crude_n", "crude_hits", "event_particles",
    "smc", "crude", "snis", "checkpoint_source", "score_source",
)


def read_csv(path):
    with path.open(encoding="utf-8", newline="") as file:
        return list(csv.DictReader(file))


def historical(root, tail_reference):
    low = root / "camera_ready_low_particle_budget"
    rows = read_csv(low / "combined_compute_scaling_runs.csv")
    tail = read_csv(low / "combined_compute_scaling_runs_q09995.csv")
    ladder = read_csv(root / "camera_ready_extreme_tail_scaling" / "runs.csv")
    for row in tail:
        row["p_reference"] = tail_reference
        row["smc_seconds_measured"] = True
        row["checkpoint_source"] = row["population_source"]
    for row in ladder:
        if float(row["lambda"]) == TILTS[0.9995]:
            rows.append(dict(row, p_reference=tail_reference,
                             campaign="camera_ready_extreme_tail_scaling"))
    return rows + tail


def progressive_rows(checkpoints, terminal, pool, references, campaign):
    terminal = {int(row["seed"]): row for row in terminal}
    seen = set()
    rows = []
    for population in checkpoints:
        seed, n = population["seed"], population["N"]
        baseline = terminal[seed]
        rank = int(baseline["replicate"])
        if (seed in seen or n != int(baseline["N"]) or population["phi"] != "logit"
                or not math.isclose(population["terminal_seconds"], float(baseline["smc_seconds"]),
                                    rel_tol=1e-12)):
            raise ValueError(f"Checkpoint provenance mismatch for seed {seed}")
        seen.add(seed)
        rate = float(baseline["crude_calibration_seconds_per_path"])
        terminal_count = int(baseline["crude_n"])
        tail, start, _ = fixed_mc_block(pool, seed_rank=rank, total_seeds=24,
                                       required=terminal_count)
        if (start != int(baseline["crude_pool_start"])
                or np.count_nonzero(tail >= 0.9995) != int(baseline["crude_hits"])
                or terminal_count != native_clock_count(population["terminal_seconds"], rate)):
            raise ValueError(f"Terminal MC comparison mismatch for seed {seed}")
        by_tilt = {cp["lambda"]: cp for cp in population["checkpoints"]}
        if len(by_tilt) != 3 or len(population["checkpoints"]) != 3:
            raise ValueError(f"Expected three intermediate checkpoints for seed {seed}")
        last_seconds = 0.0
        for threshold, tilt in TILTS.items():
            if threshold == 0.9995:
                rows.append(dict(baseline, campaign=campaign, smc_seconds_measured=True,
                                 checkpoint_source="runs.csv", score_source="terminal classifier"))
                continue
            cp = by_tilt[tilt]
            seconds = cp["runtime_seconds_cumulative"]
            arrays = [np.asarray(cp[key]) for key in ("normalized_log_weights", "scores", "rewards")]
            if (cp["sweep"] != 4 or cp["num_particles"] != n or cp["phi"] != "logit"
                    or not last_seconds < seconds < population["terminal_seconds"]
                    or any(array.shape != (n,) or not np.isfinite(array).all() for array in arrays)
                    or not np.isclose(np.logaddexp.reduce(arrays[0]), 0, atol=2e-6)
                    or np.any((arrays[1] < 0) | (arrays[1] > 1))):
                raise ValueError(f"Invalid checkpoint for seed {seed}, tilt {tilt}")
            last_seconds = seconds
            smc, snis, events = checkpoint_log_estimates(cp, threshold)
            count = native_clock_count(seconds, rate)
            prefix = tail[:count]
            if len(prefix) != count:
                raise ValueError("Intermediate MC prefix exceeds terminal budget")
            hits = int(np.count_nonzero(prefix >= threshold))
            rows.append({
                "campaign": campaign, "N": n, "seed": seed, "replicate": rank,
                "lambda": tilt, "threshold": threshold, "p_reference": references[threshold],
                "smc_seconds": seconds, "smc_seconds_measured": True,
                "smc_native_transitions": cp["native_transitions_cumulative"],
                "crude_pool_start": start, "crude_n": count, "crude_hits": hits,
                "event_particles": events, "smc": math.exp(smc), "crude": hits / count,
                "snis": math.exp(snis), "checkpoint_source": population["checkpoint_source"],
                "score_source": cp["score_source"],
            })
    if seen != terminal.keys() or Counter((int(r["N"]), float(r["threshold"])) for r in rows) != {
        (n, threshold): 24 for n in SIZES for threshold in TILTS
    }:
        raise ValueError("Incomplete campaign")
    return rows


def statistics(rows):
    grouped = {}
    for row in rows:
        threshold, tilt, n = float(row["threshold"]), float(row["lambda"]), int(row["N"])
        key = (threshold, tilt, n)
        grouped.setdefault(key, []).append(row)
    rng = np.random.default_rng(2134669)
    result = []
    for (threshold, tilt, n), group in sorted(grouped.items()):
        reference, = {float(row["p_reference"]) for row in group}
        source_tilts = "/".join(f"{value:g}" for value in sorted({float(row["lambda"]) for row in group}))
        budgets = np.array([int(row["crude_n"]) for row in group])
        for method, _, _ in METHODS:
            ratios = np.array([float(row[method]) / reference for row in group])
            for subset, values in (("all", ratios), ("positive", ratios[ratios > 0])):
                draws = values[rng.integers(len(values), size=(20000, len(values)))] if len(values) >= 2 else None
                for metric, function, minimum in (
                    ("mean_ratio", lambda x: np.mean(x, axis=-1), 1),
                    ("median_ratio", lambda x: np.median(x, axis=-1), 1),
                    ("relative_sd", lambda x: np.std(x, axis=-1, ddof=1), 2),
                    ("mean_relative_error", lambda x: np.mean(abs(x - 1), axis=-1), 1),
                    ("median_relative_error", lambda x: np.median(abs(x - 1), axis=-1), 1),
                ):
                    lo, hi = np.quantile(function(draws), [0.025, 0.975]) if draws is not None else (None, None)
                    result.append(dict(threshold=threshold, tilt=tilt, source_tilts=source_tilts,
                                       N=n, method=method, subset=subset,
                                       metric=metric, budget=budgets.mean() * reference,
                                       p_reference=reference,
                                       crude_theory_rsd=np.sqrt(np.mean((1 - reference) / (budgets * reference))),
                                       seconds=np.mean([float(row["smc_seconds"]) for row in group]),
                                       estimate=function(values) if len(values) >= minimum else None,
                                       lower_95=lo, upper_95=hi, zeros=int(np.count_nonzero(ratios == 0)),
                                       runs=len(ratios)))
    return result


def plot(rows, out, title, formula, metrics, filename, reference_line, *, zoom=False):
    fig, axes = plt.subplots(4, 2, figsize=(17, 13), sharey="row")
    for row_index, threshold in enumerate(TILTS):
        event_rows = [r for r in rows if r["threshold"] == threshold]
        points = sorted({(r["tilt"], r["N"]) for r in event_rows})
        positions = {point: i for i, point in enumerate(points)}
        all_runs = {((r["tilt"], r["N"]), r["method"]): r for r in event_rows
                    if r["subset"] == "all" and r["metric"] == metrics[0]}
        labels = []
        for point in points:
            tilt, n = point
            smc, mc = all_runs[point, "smc"], all_runs[point, "crude"]
            size = f"{n}*" if threshold == 0.9995 and tilt == 2.5 else str(n)
            budget = f"{smc['budget']:.3g}".replace(".", ",")
            labels.append(f"{size}\n{budget}\n{smc['zeros']}/{mc['zeros']}/{smc['runs']}")
        for col, (subset, subtitle) in enumerate((("all", "Tutte le repliche"), ("positive", "Sole stime positive"))):
            ax = axes[row_index, col]
            selected = {((r["tilt"], r["N"]), r["method"], r["metric"]): r
                        for r in event_rows if r["subset"] == subset}
            for method, _, color in METHODS:
                for index, metric in enumerate(metrics):
                    series = [selected[point, method, metric] for point in points]
                    x = np.array([positions[r["tilt"], r["N"]] for r in series])
                    y = np.array([r["estimate"] for r in series], dtype=float)
                    lo = np.array([r["lower_95"] for r in series], dtype=float)
                    hi = np.array([r["upper_95"] for r in series], dtype=float)
                    valid = np.isfinite(y)
                    tilts = np.array([r["tilt"] for r in series])
                    for tilt in np.unique(tilts):
                        mask = valid & (tilts == tilt)
                        ax.plot(x[mask], y[mask], "-" if index == 0 else "--",
                                color=color, marker="o" if index == 0 else "s", markersize=4)
                    if index == 0:
                        for tilt in np.unique(tilts):
                            mask = tilts == tilt
                            ax.fill_between(x[mask], lo[mask], hi[mask], color=color, alpha=.12, linewidth=0)
                        interval = np.isfinite(lo) & np.isfinite(hi)
                        isolated = interval & ~np.r_[False, interval[:-1]] & ~np.r_[interval[1:], False]
                        ax.vlines(x[isolated], lo[isolated], hi[isolated], color=color, alpha=.45)
            ax.set_xticks(range(len(points)), labels, fontsize=8)
            for label, (_, n) in zip(ax.get_xticklabels(), points, strict=True):
                if n in SIZES:
                    label.set_fontweight("bold")
            ax.grid(axis="y", alpha=.24)
            if zoom:
                cap = 3.5 if metrics == ("relative_sd",) and threshold >= .999 else 2.0
                ax.set_ylim(0, cap)
                ax.set_yticks(np.linspace(0, cap, 5) if cap == 2.0 else [0, 1, 2, 3])
            else:
                ax.set_yscale("symlog", linthresh=.01 if threshold >= .999 else .1)
            ax.yaxis.set_major_formatter(PercentFormatter(xmax=1, decimals=None))
            if reference_line:
                ax.axhline(1, color="#aa523e", lw=1, alpha=.75)
            if row_index == 0:
                ax.set_title(subtitle, loc="left", weight="bold")
            if col == 0:
                tilt_label = "λ = 2,5 / 6,5" if threshold == 0.9995 else f"λ = {TILTS[threshold]:g}"
                reference = all_runs[points[0], "smc"]["p_reference"]
                ax.set_ylabel(f"q ≥ {threshold:g}\n{tilt_label}\np rif. = {reference:.3g}".replace(".", ","))
        if not zoom:
            axes[row_index, 0].set_ylim(bottom=0)
    fig.suptitle(f"{title} — {formula}" + (" · Zoom" if zoom else ""), x=.075, y=.978,
                 ha="left", fontsize=19, weight="bold")
    fig.text(.075, .929, "Sotto ogni punto: N, budget B = n̄ MC × p rif. (eventi MC attesi), "
             "zeri SMC / zeri MC / repliche per metodo. Taglie equidistanti, nuove taglie in grassetto.",
             fontsize=10)
    handles = [Line2D([], [], color=color, label=label) for _, label, color in METHODS]
    if len(metrics) == 2:
        handles.extend([Line2D([], [], color="#333333", linestyle=line, marker=marker, label=label)
                        for line, marker, label in (("-", "o", "Media"), ("--", "s", "Mediana"))])
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5, .057), ncol=len(handles), frameon=False)
    fig.text(.5, .041, "Fasce bootstrap puntuali al 95% a riferimento fisso, per la media o la deviazione standard. "
             "Le linee collegano i punti disponibili.", ha="center", fontsize=9)
    fig.text(.5, .025, "MC a pari tempo equivalente per replica. "
             "q ≥ 0,9995: * λ = 2,5; altri punti λ = 6,5. N = 256 è mostrato per entrambi i tilt.",
             ha="center", fontsize=9)
    fig.text(.5, .009, ("Zoom lineare: valori e fasce oltre il limite sono visibili nel grafico completo."
                        if zoom else "Scala verticale lineare vicino a zero e logaritmica sopra. "
                        "Usare lo zoom per distinguere le differenze nella fascia centrale."),
             ha="center", fontsize=9)
    fig.subplots_adjust(left=.075, right=.98, top=.885, bottom=.15, hspace=.52, wspace=.13)
    fig.savefig(out / filename, dpi=190, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument("--checkpoints", type=Path)
    inputs.add_argument("--preview", action="store_true",
                        help="Render the historical panels and extend only the terminal event")
    args = parser.parse_args()
    root = args.artifacts
    study_path = Path(__file__).resolve().parents[2] / "configs/mdlm_owt_progressive_tail_particle_scaling.yaml"
    study, _ = study_configs(study_path)
    campaign = study["output_subdirectory"]
    folder = root / campaign
    terminal = read_csv(folder / "runs.csv")
    tail_reference, = {float(row["p_reference"]) for row in terminal}
    old = historical(root, tail_reference)
    references = {threshold: next(float(row["p_reference"]) for row in old
                                   if float(row["threshold"]) == threshold) for threshold in TILTS}
    if args.preview:
        new = [dict(row, campaign=campaign, smc_seconds_measured=True,
                    checkpoint_source="runs.csv", score_source="terminal classifier") for row in terminal]
        out = folder / "across_budget_preview"
        suffix = " · anteprima, nuovi punti solo per q ≥ 0,9995"
    else:
        pool, _ = validated_pool(root, study)
        with args.checkpoints.open(encoding="utf-8") as file:
            new = progressive_rows((json.loads(line) for line in file), terminal, pool, references, campaign)
        out = folder / "across_budget"
        suffix = ""
    out.mkdir(exist_ok=True)
    rows = old + new
    table = statistics(rows)
    write_csv(out / "across_budget_runs.csv", [{key: row.get(key, "") for key in FIELDS} for row in rows])
    write_csv(out / "across_budget_summary.csv", table)
    figures = (
        ("Media e mediana del rapporto", r"$\widehat p/p_{\mathrm{rif}}$",
         ("mean_ratio", "median_ratio"), "mean_median", True),
        ("Deviazione standard relativa", r"$s(\widehat p)/p_{\mathrm{rif}}$",
         ("relative_sd",), "relative_sd", False),
        ("Errore relativo assoluto", r"$|\widehat p-p_{\mathrm{rif}}|/p_{\mathrm{rif}}$",
         ("mean_relative_error", "median_relative_error"), "relative_error", True),
    )
    for title, formula, metrics, stem, line in figures:
        for zoom in (False, True):
            name = f"{stem}_across_budget{'_zoom' if zoom else ''}.png"
            plot(table, out, title + suffix, formula, metrics, name, line, zoom=zoom)
    print(f"Rendered six figures using {len(new)} new and {len(old)} historical estimates.")


if __name__ == "__main__":
    main()
