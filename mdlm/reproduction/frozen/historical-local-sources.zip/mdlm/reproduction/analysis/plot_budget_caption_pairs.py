"""Export the existing matched-cost MDLM plots with and without in-image captions."""
import argparse
from collections import defaultdict
import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np
from PIL import Image
from PIL.PngImagePlugin import PngInfo
from scipy.stats import binomtest

from plot_publication_across_budget import METHODS, REFERENCE_COUNTS, ROOT, STYLE, collect, read


OUTPUTS = ("with_captions", "without_captions")
THRESHOLD = .999
POOLED_COUNTS = (113, 975775)
METRICS = {
    "mean_relative_error": ("Mean absolute relative error", r"Mean absolute relative error (\%)",
                            lambda x: np.mean(abs(x - 1), axis=-1)),
    "median_relative_error": ("Median absolute relative error", r"Median absolute relative error (\%)",
                              lambda x: np.median(abs(x - 1), axis=-1)),
    "relative_rmse": ("Relative RMSE", r"Relative RMSE (\%)", lambda x: np.sqrt(np.mean((x - 1)**2, axis=-1))),
    "relative_sd": ("Relative standard deviation across runs", r"Relative standard deviation (\%)",
                    lambda x: np.std(x, axis=-1, ddof=1)),
    "zero_rate": ("Zero-estimate rate", r"Runs with a zero estimate (\%)", lambda x: np.mean(x == 0, axis=-1)),
    "within_factor_ten": ("Estimates within a factor of ten", r"Runs within a factor of ten (\%)",
                          lambda x: np.mean((x >= .1) & (x <= 10), axis=-1)),
    "mean_ratio": ("Mean estimate relative to reference", r"Mean estimate / reference (\%)",
                   lambda x: np.mean(x, axis=-1)),
    "median_ratio": ("Median estimate relative to reference", r"Median estimate / reference (\%)",
                     lambda x: np.median(x, axis=-1)),
    "paired_difference": ("Paired error difference", "MC minus SMC (percentage points)", np.mean),
}
PERCENT_RATES = {"zero_rate", "within_factor_ten"}
ERRORS = {"mean_relative_error", "median_relative_error"}
RATIOS = {"mean_ratio", "median_ratio"}


def estimate_record(n, method, budget, values, statistic, indices):
    if not values.size:
        value, lower, upper = np.nan, np.nan, np.nan
    else:
        value = statistic(values)
        lower, upper = (np.quantile(statistic(values[indices]), [.025, .975])
                        if indices is not None else (np.nan, np.nan))
    return dict(N=n, method=method, budget=budget, estimate=value, lower=lower, upper=upper)


def pooled_series(runs, summaries, references):
    updated_thresholds = {q for q, counts in references.items() if counts != REFERENCE_COUNTS[q]}
    for key in [k for k in summaries if k[0] in updated_thresholds]:
        summaries[key].clear()

    # The 256–512 review uses the same resamples across its three metrics.
    review_rng = np.random.default_rng(2134669)
    legacy_rng = np.random.default_rng(2134669)
    positive_rng = np.random.default_rng(2134669)
    for (q, tilt, n), group in sorted(runs.items()):
        if q not in updated_thresholds:
            continue
        hits, total = references[q]
        reference = hits / total
        assert len({row["seed"] for row in group}) == len(group)
        budget = np.mean([int(row["crude_n"]) for row in group]) * reference
        rng = review_rng if q == THRESHOLD and tilt == 2.5 and n >= 256 else legacy_rng
        draws = rng.integers(len(group), size=(20000, len(group)))
        ratios = {method: np.array([float(row[method]) for row in group]) / reference for method, *_ in METHODS}
        for method, values in ratios.items():
            historical_review = q == THRESHOLD and tilt == 6.5
            keys = ("mean_relative_error", "relative_rmse", "relative_sd", "zero_rate") if historical_review else (
                "mean_relative_error", "median_relative_error", "relative_rmse", "relative_sd",
                "zero_rate", "within_factor_ten", "mean_ratio", "median_ratio",
            )
            for metric in keys:
                statistic = METRICS[metric][2]
                indices = None if metric == "within_factor_ten" else draws
                summaries.setdefault((q, tilt, "all", metric), []).append(
                    estimate_record(n, method, budget, values, statistic, indices))
            if not historical_review:
                positive = values[values > 0]
                indices = (positive_rng.integers(positive.size, size=(20000, positive.size))
                           if positive.size >= 2 else None)
                for metric in ("mean_relative_error", "median_relative_error", "relative_sd", "mean_ratio", "median_ratio"):
                    eligible = positive[:0] if metric == "relative_sd" and positive.size < 2 else positive
                    summaries[q, tilt, "positive", metric].append(
                        estimate_record(n, method, budget, eligible, METRICS[metric][2], indices))
        if q == THRESHOLD and tilt == 2.5:
            delta = abs(ratios["crude"] - 1) - abs(ratios["smc"] - 1)
            summaries[q, tilt, "all", "paired_difference"].append(
                estimate_record(n, "paired", budget, delta, METRICS["paired_difference"][2], draws))


def add_zero_intervals(runs, summaries):
    rng = np.random.default_rng(2134669)
    for (q, tilt, subset, metric), records in sorted(summaries.items()):
        if metric != "zero_rate" or all(np.isfinite(r["lower"]) for r in records):
            continue
        for n in sorted({r["N"] for r in records}):
            group = runs[q, tilt, n]
            draws = rng.integers(len(group), size=(20000, len(group)))
            for r in (item for item in records if item["N"] == n):
                zeros = np.array([float(row[r["method"]]) == 0 for row in group])
                np.testing.assert_allclose(r["estimate"], zeros.mean())
                r["lower"], r["upper"] = np.quantile(zeros[draws].mean(axis=1), [.025, .975])


def caption(q, tilt, subset, metric, cohorts, records, scale, references):
    hits, total = references[q]
    ci = binomtest(hits, total).proportion_ci(method="wilson")
    counts = {len(group) for group in cohorts}
    if len(counts) == 1:
        count_text = f"{counts.pop()} independent runs per method and budget."
    else:
        sizes = sorted({r["N"] for r in records})
        by_count = defaultdict(list)
        for n, group in zip(sizes, cohorts, strict=True):
            by_count[len(group)].append(str(n))
        count_text = "Runs per method: " + "; ".join(
            f"{count} at $N={','.join(group_sizes)}$" for count, group_sizes in sorted(by_count.items())
        ) + "."
    config = rf"$q\geq {q:g}$, $\lambda={tilt:g}$. "
    lines = [config + count_text,
             r"$B=\overline{N}_{\mathrm{MC,equiv}}p_{\mathrm{ref}}$. "
             r"$B=1$ is one expected rare event under compute-matched crude MC."]
    math_total = f"{total:,}".replace(",", "{,}")
    exponent = int(np.floor(np.log10(hits / total)))
    low, high = ci.low / 10.0**exponent, ci.high / 10.0**exponent
    lines.append(rf"$p_{{\mathrm{{ref}}}}={hits}/{math_total}$. "
                 rf"95\% Wilson CI: $[{low:.3g},\,{high:.3g}]\times10^{{{exponent}}}$.")
    descriptions = {
        "mean_relative_error": r"Mean of $|\widehat p/p_{\mathrm{ref}}-1|$ across runs.",
        "median_relative_error": r"Median of $|\widehat p/p_{\mathrm{ref}}-1|$ across runs.",
        "relative_rmse": r"Root mean square of $\widehat p/p_{\mathrm{ref}}-1$ across runs.",
        "relative_sd": r"Sample standard deviation of $\widehat p$ across runs, divided by $p_{\mathrm{ref}}$.",
        "zero_rate": r"Fraction of runs with $\widehat p=0$.",
        "within_factor_ten": r"Fraction of runs with $0.1\leq\widehat p/p_{\mathrm{ref}}\leq10$.",
        "mean_ratio": r"Mean of $\widehat p/p_{\mathrm{ref}}$ across runs.",
        "median_ratio": r"Median of $\widehat p/p_{\mathrm{ref}}$ across runs.",
        "paired_difference": "Paired difference in absolute relative error. Positive values favor SMC.",
    }
    lines.append(descriptions[metric] + (" Zeros included." if subset == "all" and metric != "zero_rate" else ""))
    if any(np.isfinite(r["lower"]) and np.isfinite(r["upper"]) for r in records):
        paired = " paired" if metric == "paired_difference" else ""
        lines.append(rf"Bars: pointwise 95\%{paired} bootstrap intervals (20,000 resamples, fixed $p_{{\mathrm{{ref}}}}$).")
    if subset == "positive":
        lines.append("Each method uses only its positive estimates. Undefined points are omitted.")
        for method, label, *_ in METHODS:
            counts = [str(sum(float(row[method]) > 0 for row in group)) for group in cohorts]
            lines.append(f"{label} positive runs in budget order: {', '.join(counts)}.")
    if metric in ERRORS:
        lines.append(r"Dotted line: 100\% error of a zero estimate.")
    elif metric in RATIOS:
        lines.append(r"Dotted line: 100\% denotes agreement with the reference.")
    elif metric == "zero_rate":
        for method, label, *_ in METHODS:
            zeros = [str(sum(float(row[method]) == 0 for row in group)) for group in cohorts]
            lines.append(f"{label} zero counts in budget order: {', '.join(zeros)}.")
    if total == POOLED_COUNTS[1]:
        lines.append("The pooled reference includes the matched MC pool.")
    if any(row["smc_seconds_measured"] == "False" for group in cohorts for row in group):
        lines.append("Some historical checkpoint budgets use reconstructed SMC times.")
    if scale == "symlog":
        lines.append("Vertical scale is linear near zero and logarithmic at large values.")
    return lines


def draw(ax, records, metric):
    title, ylabel, _ = METRICS[metric]
    methods = METHODS if metric != "paired_difference" else (("paired", "", "#414957", "o"),)
    for method, label, color, marker in methods:
        series = sorted((row for row in records if row["method"] == method), key=lambda row: row["budget"])
        x, y, lo, hi = np.array([[r[k] for k in ("budget", "estimate", "lower", "upper")] for r in series]).T
        ax.plot(x, y, color=color, marker=marker, label=label, zorder=3)
        valid = np.isfinite(lo) & np.isfinite(hi)
        ax.vlines(x[valid], lo[valid], hi[valid], color=color, linewidth=1, zorder=2)
        for end in (lo, hi):
            ax.plot(x[valid], end[valid], linestyle="none", marker="_", color=color, ms=7, mew=1, zorder=2)
    if metric in ERRORS | RATIOS | {"paired_difference"}:
        ax.axhline(0 if metric == "paired_difference" else 1, color="#777777", linestyle=":", lw=.9)
    if metric in PERCENT_RATES:
        ax.set_ylim(-.025, 1.045)
        ax.set_yticks([0, .25, .5, .75, 1])
    elif metric != "paired_difference":
        if ax.get_ylim()[1] > 8:
            ax.set_yscale("symlog", linthresh=.1)
            ax.set_ylim(bottom=-.008)
        else:
            ax.set_ylim(bottom=-.015 * ax.get_ylim()[1])
    budgets = sorted({r["budget"] for r in records})
    indices = np.linspace(0, len(budgets) - 1, min(6, len(budgets))).round().astype(int)
    ticks = [budgets[i] for i in indices]
    decimals = 3 if max(ticks) < .2 else 2
    ax.set_xticks(ticks, [f"{b:.{decimals}f}" for b in ticks])
    ax.margins(x=.08)
    ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=0, symbol="" if metric == "paired_difference" else "%"))
    ax.set_xlabel("Expected rare events under equal-cost MC")
    ax.set_ylabel(ylabel)
    ax.minorticks_off()
    return title


def save_pair(key, records, runs, destination, references):
    q, tilt, subset, metric = key
    budgets = {r["N"]: r["budget"] for r in records}
    cohorts = [runs[q, tilt, n] for n in sorted(budgets, key=budgets.get)]
    tag = f"q{q:g}_lambda{tilt:g}".replace(".", "p")
    stem = metric + ("_positive" if subset == "positive" else "")
    captioned, paper = [destination / folder / tag / f"{stem}.png" for folder in OUTPUTS]
    if captioned.is_file():
        if not paper.is_file():
            crop_caption(captioned, paper)
        return
    width, plot_height = 7.7, 4.18
    fig = plt.figure(figsize=(width, plot_height))
    ax = fig.add_axes([.16, .15, .80, .66])
    title = draw(ax, records, metric)
    scale = ax.get_yscale()
    lines = caption(q, tilt, subset, metric, cohorts, records, scale, references)
    extra = .24 + len(lines) * .19
    height = plot_height + extra
    fig.set_size_inches(width, height)
    ax.set_position([.16, (extra + .15 * plot_height) / height, .80, .66 * plot_height / height])
    full_title = title + (" (positive estimates)" if subset == "positive" else "")
    fig.text(.16, 1 - .18 / height, rf"\textbf{{{full_title}}}", fontsize=16, va="top")
    if metric != "paired_difference":
        fig.legend(loc="upper left", bbox_to_anchor=(.143, 1 - .46 / height), ncols=2, frameon=False)
    metadata = {"Title": full_title, "Description": " ".join(lines)}
    for folder in OUTPUTS:
        (destination / folder / tag).mkdir(parents=True, exist_ok=True)
    assert len(fig.axes) == 1
    for i, line in enumerate(lines):
        fig.text(.16, (extra - .06 - i * .19) / height, line, fontsize=10, va="top")
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    tight = fig.get_tightbbox(renderer)
    if tight.x1 > width or tight.x0 < 0 or tight.y1 > height or tight.y0 < 0:
        raise ValueError(f"Text outside figure: {key} ({tight.bounds})")
    fig.savefig(captioned, metadata=metadata)
    plt.close(fig)
    crop_caption(captioned, paper)


def crop_caption(captioned, paper):
    """Keep exactly the same pixels for the title, legend, and plot."""
    with Image.open(captioned) as image:
        metadata = PngInfo()
        for key in ("Title", "Description"):
            metadata.add_text(key, image.info[key])
        plot_rows = int(4.18 * STYLE["savefig.dpi"])
        image.crop((0, 0, image.width, plot_rows)).save(paper, pnginfo=metadata, dpi=image.info["dpi"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tilt-6p5-runs", type=Path, required=True)
    parser.add_argument("--pooled-reference", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=ROOT)
    args = parser.parse_args()
    reference_data = json.loads(args.pooled_reference.read_bytes())
    references = {row["threshold"]: (row["hits"], row["samples"]) for row in reference_data["references"]}
    assert references.keys() <= REFERENCE_COUNTS.keys()
    assert all(0 < hits < total == POOLED_COUNTS[1] for hits, total in references.values())
    assert references[THRESHOLD] == POOLED_COUNTS
    runs, summaries = collect()
    additional = defaultdict(list)
    for row in read(args.tilt_6p5_runs):
        assert float(row["threshold"]) == THRESHOLD and float(row["lambda"]) == 6.5
        additional[THRESHOLD, 6.5, int(row["N"])].append(row)
    ladder = ROOT.parent.parent / "camera_ready_same_run_logit/checkpoint_runs_3_thresholds.csv"
    additional[THRESHOLD, 6.5, 128] = [
        dict(row, smc_seconds_measured="True") for row in read(ladder)
        if float(row["threshold"]) == THRESHOLD and float(row["lambda"]) == 6.5 and row["sweep"] == "4"
        and row["phi"] == "logit" and row["MC_comparison_available"] == "True"]
    assert {n: len(group) for (_, _, n), group in additional.items()} == {
        128: 12, 256: 12, 320: 24, 384: 24, 448: 24, 512: 24,
    }
    for group in additional.values():
        for row in group:
            if "crude_event_particles" in row:
                np.testing.assert_allclose(float(row["crude"]), int(row["crude_event_particles"]) / int(row["crude_n"]))
    assert not runs.keys() & additional.keys()
    runs.update(additional)
    pooled_series(runs, summaries, references)
    add_zero_intervals(runs, summaries)
    for folder in OUTPUTS:
        (args.output / folder).mkdir(exist_ok=True)
    with plt.rc_context({**STYLE, "font.size": 12, "axes.labelsize": 13, "legend.fontsize": 12,
                         "lines.linewidth": 1.8, "lines.markersize": 6}):
        for key, records in sorted(summaries.items()):
            if key[0] in references:
                save_pair(key, records, runs, args.output, references)
    count = sum(key[0] in references for key in summaries)
    print(f"Exported {count} matched PNG pairs in {args.output}.")


if __name__ == "__main__":
    main()
