"""Stage the original terminal runs for the paper campaign after validating provenance."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from .accuracy_budget import assigned_runs, study_configs
from .particle_scaling import audit_population, calibration_for, comparison_rows, validated_pool
from .storage import atomic_write_json, file_hash as sha256, read_json


def copy_verified(source, destination, digest):
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        temporary = destination.with_name(destination.name + ".staging")
        shutil.copyfile(source, temporary)
        if sha256(temporary) != digest:
            raise ValueError(f"Staged copy differs from {source}")
        temporary.replace(destination)
    if sha256(destination) != digest:
        raise ValueError(f"Existing artifact differs from {source}")


def stage(study_path, output_root, workers=3):
    study, configs = study_configs(study_path)
    if not study.get("paper_final_scaling"):
        raise ValueError("Select the paper campaign")
    old_root = output_root / study["reuse_campaign"]
    root = output_root / study["output_subdirectory"]
    if old_root.resolve() == root.resolve():
        raise ValueError("The source and destination must be distinct")
    status = read_json(old_root / "report_status.json")
    reuse_counts = set(study["reuse_particle_counts"])
    expected = study["independent_runs"] * len(reuse_counts)
    if status != dict(completed_runs=expected, expected_runs=expected, complete=True):
        raise ValueError("The original campaign is incomplete")

    files = {}
    plan = {}
    for worker in range(workers):
        worker_dir = Path("workers") / f"worker_{worker}"
        manifest_file = old_root / worker_dir / "manifest.json"
        manifest = read_json(manifest_file)
        original = {c["_exploration"]["id"]: c for c in manifest["resolved_configs"]}
        original_seeds = set(manifest["planned_seeds"])
        if manifest["study"]["thresholds"] != study["recorded_thresholds"]:
            raise ValueError("The archived score recording policy differs")
        for name, digest in manifest["source_SHA256"].items():
            if name in {"accuracy_budget.py", "same_run_reuse.py"}:
                continue  # Orchestration files changed to describe the new seed plan.
            if sha256(Path(__file__).with_name(name)) != digest:
                raise ValueError(f"Frozen sampler source differs from the original manifest for {name}")
        reused = {}
        for config, seed in assigned_runs(study, configs, worker, workers):
            case = config["_exploration"]
            if case["N"] not in reuse_counts:
                continue
            archived = original[case["id"]]
            resolved = {**config, "_exploration": {k: v for k, v in case.items() if k != "seed_start"}}
            if seed not in original_seeds or resolved != archived:
                raise ValueError(f"Resolved configuration or seed differs for {seed}")
            relative = worker_dir / "populations" / f"{case['id']}_seed{seed}.json"
            path = old_root / relative
            data = read_json(path)
            if data["summary"]["seed"] != seed or not data["level_diagnostics"][-1]["terminal"]:
                raise ValueError(f"Mismatched seed or nonterminal population for {seed}")
            audit_population(data, config)
            calibration, _ = calibration_for(old_root, data)
            files[calibration.relative_to(old_root)] = sha256(calibration)
            files[relative] = sha256(path)
            reused[seed] = str(relative.as_posix())
        if original_seeds != set(reused):
            raise ValueError(f"The reused seed inventory differs for worker {worker}")
        plan[str(worker)] = dict(manifest_sha256=sha256(manifest_file),
                                 source_sha256=manifest["source_SHA256"], populations=reused)

    for path, digest in files.items():
        copy_verified(old_root / path, root / path, digest)
    pool, _ = validated_pool(output_root, study)
    rows, staged = comparison_rows(study, configs, root, pool)
    if staged["completed_runs"] < expected or len(rows) != len(study["thresholds"]) * staged["completed_runs"]:
        raise ValueError("The staged populations do not cover every requested checkpoint")
    atomic_write_json(root / "reuse_manifest.json", dict(
        source_campaign=study["reuse_campaign"], reused_populations=expected,
        workers=plan, files_sha256={p.as_posix(): v for p, v in files.items()},
    ))
    return expected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    args = parser.parse_args()
    count = stage(args.study, args.output_root)
    print(f"Verified and staged {count} original terminal populations", flush=True)


if __name__ == "__main__":
    main()
