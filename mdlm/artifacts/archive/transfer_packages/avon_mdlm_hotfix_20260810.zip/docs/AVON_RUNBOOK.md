# Avon runbook: unconditional MDLM toxicity smoke benchmark

This runbook prepares two non-production pipelines for the unconditional
MDLM-OWT distribution. It does not reproduce FK Steering's prompt-conditioned
experiment. Do not compare the resulting toxicity probability with FK's
reported prompt-conditioned rate.

No experiment, installation, Python process, model load, or download may run on
an Avon login node. Only the read-only preflight and `sbatch` submission belong
there. No script modifies `.bashrc` or contains a Hugging Face token.

## Persistent paths

```bash
export PROJECT_DIR=/gpfs/home/stats/stuhvh/rea_of_llms_supplementary_code
export OUTPUT_ROOT=/gpfs/home/stats/stuhvh/rea_of_llms_supplementary_code/outputs
export HF_HOME=/gpfs/home/stats/stuhvh/hf-cache
export VENV_DIR=/gpfs/home/stats/stuhvh/venvs/toxicity-smc
```

## 1. Read-only preflight after login

```bash
cd /gpfs/home/stats/stuhvh/rea_of_llms_supplementary_code
bash scripts/avon_preflight.sh
```

Verify:

- Avon login hostname and `/gpfs/home/stats/stuhvh` mount/quota;
- account association and allowed QoS;
- partition state, GPU GRES, and maximum wall time;
- the Python 3.11 prerequisite chain from `module spider`;
- CUDA/PyTorch module metadata without loading modules.

Previously observed candidates are account `stats`, QoS `normal`, partitions
`gpu-devel` and `gpu`, GRES `gpu:quadro_rtx_6000:1`, and modules
`GCCcore/13.2.0 Python/3.11.5`. Use them only after the current preflight
confirms them. If a SLURM query fails, stop and diagnose that exact error.

## 2. Export verified scheduler values

Replace values below only with preflight-confirmed values:

```bash
export AVON_ACCOUNT=stats
export AVON_PARTITION=gpu-devel
export AVON_QOS=normal
export AVON_GPU_GRES=gpu:quadro_rtx_6000:1
export AVON_MODULES='GCCcore/13.2.0 Python/3.11.5'
```

Account, partition, QoS, and module choices are not embedded in the new SLURM
jobs. The submit script refuses to continue without the mandatory exports.

## 3. Validate Bash syntax on the login node

This is read-only and executes none of the scripts:

```bash
cd /gpfs/home/stats/stuhvh/rea_of_llms_supplementary_code
bash -n \
  scripts/avon_job_common.sh \
  scripts/avon_preflight.sh \
  scripts/avon_setup_environment.sh \
  scripts/slurm_avon_prefetch_models.sh \
  scripts/slurm_avon_smoke_direct.sh \
  scripts/slurm_avon_smoke_score.sh \
  scripts/slurm_avon_smoke_smc.sh \
  scripts/slurm_avon_smoke_compare.sh \
  scripts/submit_avon_smoke_pipeline.sh
```

## 4. Create the environment on an allocated compute node

After reviewing the exact request, allocate one GPU with verified values:

```bash
srun \
  --account="${AVON_ACCOUNT}" \
  --partition="${AVON_PARTITION}" \
  --qos="${AVON_QOS}" \
  --gres="${AVON_GPU_GRES}" \
  --nodes=1 \
  --ntasks=1 \
  --cpus-per-task=2 \
  --mem=8G \
  --time=00:30:00 \
  --pty bash -l
```

Only after the shell is on a compute node:

```bash
export AVON_MODULES='GCCcore/13.2.0 Python/3.11.5'
export PROJECT_DIR=/gpfs/home/stats/stuhvh/rea_of_llms_supplementary_code
export VENV_DIR=/gpfs/home/stats/stuhvh/venvs/toxicity-smc
export HF_HOME=/gpfs/home/stats/stuhvh/hf-cache
bash "${PROJECT_DIR}/scripts/avon_setup_environment.sh"
exit
```

The environment pins PyTorch 2.6.0 cu118, required for safe loading of the
classifier checkpoint with Transformers 4.57.6. MDLM uses FP32 and the
classifier uses FP16. FlashAttention, `bfloat16`, bitsandbytes, and native CUDA
compilation are not enabled. If compute nodes lack outbound access, stop; do
not move setup or downloads to the login node.

## 5. Review without submitting

In the login shell, export the persistent paths and verified scheduler values,
then run:

```bash
cd "${PROJECT_DIR}"
bash scripts/submit_avon_smoke_pipeline.sh technical --dry-run
```

For the scientific smoke, first select a verified partition supporting the
printed four-hour direct and twelve-hour SMC requests:

```bash
export AVON_PARTITION=gpu
bash scripts/submit_avon_smoke_pipeline.sh scientific --dry-run
```

The full dry run prints account, partition, GRES, GPU/CPU/RAM/time, config,
exact commands, outputs, and logs for every stage. A stage-specific dry run is
also available and submits nothing:

```bash
bash scripts/submit_avon_smoke_pipeline.sh technical --stage prefetch --dry-run
```

## 6. Submit one stage at a time after dry-run verification

The old multi-job `--submit` mode is intentionally disabled. Each invocation
below performs at most one `sbatch` call and prints one job ID. On a cluster
with a one-job submission limit, wait until each job is `COMPLETED`, verify its
log, and then explicitly submit the next stage without a dependency:

```bash
bash scripts/submit_avon_smoke_pipeline.sh technical --stage prefetch
# Verify PREFETCH_ID is COMPLETED.
bash scripts/submit_avon_smoke_pipeline.sh technical --stage direct --no-dependency
# Verify DIRECT_ID is COMPLETED.
bash scripts/submit_avon_smoke_pipeline.sh technical --stage score --no-dependency
# Verify SCORE_ID is COMPLETED.
bash scripts/submit_avon_smoke_pipeline.sh technical --stage smc --no-dependency
# Verify SMC_ID is COMPLETED.
bash scripts/submit_avon_smoke_pipeline.sh technical --stage compare --no-dependency
```

Where the submission limit permits one pending dependent job, preserve SLURM
ordering explicitly by supplying the immediately preceding job ID:

```bash
bash scripts/submit_avon_smoke_pipeline.sh technical --stage direct --afterok PREFETCH_ID
bash scripts/submit_avon_smoke_pipeline.sh technical --stage score --afterok DIRECT_ID
bash scripts/submit_avon_smoke_pipeline.sh technical --stage smc --afterok SCORE_ID
bash scripts/submit_avon_smoke_pipeline.sh technical --stage compare --afterok SMC_ID
```

For the scientific profile, first set the verified longer partition and use
the same stage sequence with `scientific`:

```bash
export AVON_PARTITION=gpu
bash scripts/submit_avon_smoke_pipeline.sh scientific --stage prefetch
```

The logical order remains:

```text
prefetch -> direct -> score -> SMC -> compare
```

The technical config is
`configs/mdlm_owt_unconditional_smoke_technical.yaml`: 128 positions, 32
denoising steps, 2 IID direct samples, 8 particles, 2 independent runs,
tilted lambdas `[5,10]`, uniform weights `[0.5,0.5]`, and diagnostic lambda
`[0]`.

The scientific config is
`configs/mdlm_owt_unconditional_smoke_scientific.yaml`: 128 positions, 1,000
steps, 2 IID direct samples, 8 particles, 1 run, the same two tilted lambdas,
and the separate zero diagnostic. Values 5 and 10 exercise the pipeline and
are not asserted to be optimal.

Both start from exactly `[MASK]^128`, with no BOS/EOS, prompt, or fixed prefix.
The upstream MDLM diffusion sampler was verified to use this all-mask prior;
BOS insertion exists only in its autoregressive sampler.

DDPM transitions are stochastic. If masks remain after the last transition,
this benchmark removes them with a categorical model draw rather than argmax.
Deterministic argmax completion is used only for an intermediate SMC reward
evaluation and that temporary completion is discarded.

Expected identifiers will change whenever the decoder manifest changes:

```text
technical decoder_id:  cb78b724cdaa4a7ec1c91955be80de5e169f77ab776a98ec3ae1dc6aa0cfb609
scientific decoder_id: 98719063a58345c23c4726c2e02cb838a447890669c05fef32cfcaa7fecf85fd
evaluator_id:          ae3f157a1521ef7f986ba734d14c0277c96a4754fd6b74693c6d92ebc7b9a60c
```

Direct and SMC comparison rejects any different `decoder_id` or `evaluator_id`.
Old prompt-conditioned artifact directories remain untouched and are never
selected by these new identifiers.

## 7. Monitor logs, memory, and artifacts

Record the one ID printed by each stage invocation:

```bash
squeue -j PREFETCH_ID,DIRECT_ID,SCORE_ID,SMC_ID,COMPARE_ID
sacct -j PREFETCH_ID,DIRECT_ID,SCORE_ID,SMC_ID,COMPARE_ID \
  --format=JobID,JobName,Partition,Account,State,Elapsed,Timelimit,ReqMem,AllocTRES,ExitCode
tail -n 100 logs/mdlm-smoke-smc-SMC_ID.out
tail -n 100 logs/mdlm-smoke-smc-SMC_ID.err
grep -R --line-number 'peak_cuda_memory_allocated_bytes' logs outputs/mdlm_owt
find outputs/mdlm_owt -maxdepth 7 -type f -printf '%p %s bytes\n' | sort
```

Generation rows store `conditioning_mode: unconditional`, all 128 terminal
tokens, and decoded text. Scoring artifacts contain classifier inputs/logits,
rewards, and events. SMC stores tilted and diagnostic components separately,
including reverse weights, ESS, genealogy, NFE, runtime, and completions.

Successful artifacts verify CUDA/model/classifier loading, all-mask initial
state, empty fixed prefix, no terminal mask, finite values, separate
reverse-SNIS ratios for lambdas 5 and 10, arithmetic-mean aggregation, excluded
zero diagnostic, IID binomial/Wilson direct baseline, matching identifiers,
and duplicate-free resume.

## 8. Resume

After diagnosing an interruption, resubmit only the interrupted stage. Use
`--afterok PREVIOUS_ID` when the prerequisite is still active, or
`--no-dependency` only after verifying it already completed. Direct scans global
sample indices and creates only missing samples up to `target_samples=2`; the
smoke direct job performs a second no-op resume scan. Scoring skips complete
shards, SMC skips complete run/lambda component JSON files, and completed
comparisons are reused. Existing prompt-conditioned or unconditional outputs
are never deleted.

## 9. Scaling after both smoke profiles pass

Increase one dimension at a time:

1. independent SMC runs;
2. particles, while monitoring peak VRAM;
3. the direct `target_samples` pilot size;
4. generation microbatch size only after memory measurements.

Keep 1,000 steps for scientific runs. Do not yet change the stochastic DDPM
kernel or terminal categorical completion, reward/event definition,
deterministic intermediate argmax completion, or uniform tilted-component
weights. No 10,000-sample production job is submitted or encoded as a default.
