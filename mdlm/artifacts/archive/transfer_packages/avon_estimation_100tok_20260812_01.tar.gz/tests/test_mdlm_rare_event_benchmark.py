from __future__ import annotations

import copy
import json
import math
import os
import tomllib
from pathlib import Path

import pytest
import torch
from setuptools import find_packages

from diffusion_toxicity_smc_experiment.ancestral import (
    NativeMDLMSampler,
    subs_log_probabilities,
)
from diffusion_toxicity_smc_experiment.calibration_report import (
    build_calibration_report,
)
from diffusion_toxicity_smc_experiment.compare import compare_existing
from diffusion_toxicity_smc_experiment.configuration import (
    decoder_id,
    decoder_manifest,
    evaluator_id,
    load_yaml,
    validate_benchmark_config,
)
from diffusion_toxicity_smc_experiment.evaluation import (
    direct_unconditional_summary,
    unconditional_mdlm_prefix_classifier_text,
    unconditional_trimmed_classifier_text,
)
from diffusion_toxicity_smc_experiment.generate_direct import direct_run_directory
from diffusion_toxicity_smc_experiment.run_smc import (
    UnconditionalToxicityFunctions,
    _aggregate,
    _component_seed,
    smc_manifest,
)
from diffusion_toxicity_smc_experiment.runtime import load_generator_runtime
from diffusion_toxicity_smc_experiment.score_direct import (
    _write_summary_snapshot,
    latest_direct_summary_path,
)
from diffusion_toxicity_smc_experiment.smc import (
    SMCComponentConfig,
    aggregate_component_estimates,
    normalize_log_weights,
    resample_indices,
    reverse_snis_component,
    run_smc_component,
    telescoping_log_increments,
)
from diffusion_toxicity_smc_experiment.storage import (
    atomic_write_jsonl,
    initialize_manifest,
    missing_indices,
    scan_direct_generations,
)


def minimal_config() -> dict:
    return {
        "decoder": {
            "checkpoint": {"id": "model", "revision": "abc"},
            "model_implementation": {"id": "implementation", "revision": "def"},
            "tokenizer": {"id": "tokenizer", "revision": "ghi"},
            "generation_mode": "unconditional",
            "fixed_prefix_token_ids": [],
            "prompt": None,
            "predictor": "ddpm",
            "temperature": 1.0,
            "top_k": None,
            "top_p": None,
            "sequence_length": 4,
            "evaluated_completion_tokens": 2,
            "denoising_steps": 2,
            "noise_schedule": {"type": "loglinear", "epsilon": 0.001},
            "sampling_epsilon": 1e-5,
            "final_noise_removal": True,
            "final_noise_removal_method": "stochastic_categorical",
            "mask_token_id": 2,
            "precision": "float32",
        },
        "evaluation": {
            "classifier": {"id": "classifier", "revision": "jkl"},
            "reward": {"definition": "reward"},
            "event": {"definition": "event"},
        },
        "smc": {
            "num_particles": 2,
            "independent_runs": 1,
            "tilted_lambdas": [5.0, 10.0],
            "tilted_component_weights_a": [0.5, 0.5],
            "component_weight_policy": "uniform",
            "optimize_component_weights": False,
            "diagnostic_lambdas": [0.0],
        },
    }


def generation_row(*, sample_id: str, sample_index: int, identifier: str) -> dict:
    return {
        "sample_id": sample_id,
        "sample_index": sample_index,
        "conditioning_mode": "unconditional",
        "shard_seed": 7,
        "position_in_shard": sample_index,
        "token_ids": [0, 1],
        "completion_token_ids": [0, 1],
        "decoded_text": "xy",
        "checkpoint_revision": "abc",
        "tokenizer_revision": "ghi",
        "decoder_id": identifier,
        "generated_at_utc": "2026-01-01T00:00:00+00:00",
    }


class NoOpModel:
    def __call__(self, **kwargs):  # pragma: no cover - initial state test never calls it
        raise AssertionError(kwargs)


class UniformTwoTokenModel:
    """Assign equal mass to tokens 0 and 1; token 2 is the absorbing mask."""

    def __call__(self, *, input_ids, timesteps, return_dict=False):
        del timesteps, return_dict
        return (torch.zeros((*input_ids.shape, 3), device=input_ids.device),)


@pytest.mark.parametrize("batch_size", [1, 3])
def test_subs_mixed_masked_and_revealed_positions(batch_size: int) -> None:
    mask_token_id = 4
    state_rows = [
        [mask_token_id, 2, mask_token_id, 1],
        [0, mask_token_id, 3, mask_token_id],
        [mask_token_id, mask_token_id, 1, 2],
    ]
    states = torch.tensor(state_rows[:batch_size], dtype=torch.long)
    raw_logits = torch.arange(
        batch_size * states.shape[1] * 5, dtype=torch.float32
    ).reshape(batch_size, states.shape[1], 5)

    actual = subs_log_probabilities(
        raw_logits, states, mask_token_id=mask_token_id
    )

    assert actual.shape == (batch_size, states.shape[1], 5)
    assert bool(torch.isneginf(actual[..., mask_token_id]).all())

    masked = states == mask_token_id
    expected_masked_logits = raw_logits.float().clone()
    expected_masked_logits[..., mask_token_id] = -torch.inf
    expected_masked = torch.log_softmax(expected_masked_logits, dim=-1)
    torch.testing.assert_close(actual[masked], expected_masked[masked])

    revealed = ~masked
    revealed_rows = actual[revealed]
    revealed_token_ids = states[revealed]
    assert bool((revealed_rows.gather(1, revealed_token_ids.unsqueeze(1)) == 0.0).all())
    off_token = torch.ones_like(revealed_rows, dtype=torch.bool)
    off_token.scatter_(1, revealed_token_ids.unsqueeze(1), False)
    assert bool(torch.isneginf(revealed_rows[off_token]).all())


def test_subs_rejects_malformed_four_dimensional_logits() -> None:
    states = torch.tensor([[4, 1, 4, 2]], dtype=torch.long)
    malformed = torch.zeros((1, 1, 4, 5), dtype=torch.float32)
    with pytest.raises(
        ValueError,
        match=r"logits shape \(1, 1, 4, 5\).*states shape \(1, 4\)",
    ):
        subs_log_probabilities(malformed, states, mask_token_id=4)


def test_unconditional_initial_state_is_exactly_l_masks_without_prefix() -> None:
    sampler = NativeMDLMSampler(NoOpModel(), mask_token_id=7)
    states, prefix = sampler.initial_states(
        batch_size=3,
        sequence_length=5,
        device="cpu",
        fixed_prefix_token_ids=torch.empty(0, dtype=torch.long),
    )
    assert states.shape == (3, 5)
    assert bool((states == 7).all())
    assert prefix.numel() == 0


def test_terminal_mask_removal_is_stochastic_not_argmax() -> None:
    sampler = NativeMDLMSampler(
        UniformTwoTokenModel(),
        mask_token_id=2,
        final_noise_removal_method="stochastic_categorical",
    )
    states = torch.full((64, 4), 2, dtype=torch.long)
    completed = sampler.terminal_completion(
        states,
        t_scalar=1e-5,
        generator=torch.Generator().manual_seed(1234),
    )
    assert not bool((completed == 2).any())
    assert set(completed.unique().tolist()) == {0, 1}


def test_terminal_sampling_microbatch_preserves_draw_and_bounds_forward_batch() -> None:
    states = torch.full((5, 4), 2, dtype=torch.long)
    full_sampler = NativeMDLMSampler(
        UniformTwoTokenModel(),
        mask_token_id=2,
        final_noise_removal_method="stochastic_categorical",
    )
    chunked_sampler = NativeMDLMSampler(
        UniformTwoTokenModel(),
        mask_token_id=2,
        final_noise_removal_method="stochastic_categorical",
    )
    full = full_sampler.terminal_completion(
        states,
        t_scalar=1e-5,
        generator=torch.Generator().manual_seed(22),
    )
    chunked = chunked_sampler.terminal_completion(
        states,
        t_scalar=1e-5,
        generator=torch.Generator().manual_seed(22),
        microbatch_size=2,
    )
    torch.testing.assert_close(chunked, full)
    assert full_sampler.nfe == 1
    assert chunked_sampler.nfe == 3


def test_ddpm_microbatch_preserves_transition_draw() -> None:
    states = torch.full((5, 4), 2, dtype=torch.long)
    full_sampler = NativeMDLMSampler(UniformTwoTokenModel(), mask_token_id=2)
    chunked_sampler = NativeMDLMSampler(UniformTwoTokenModel(), mask_token_id=2)
    full, _ = full_sampler.ddpm_step(
        states,
        t_scalar=0.5,
        dt=0.1,
        generator=torch.Generator().manual_seed(91),
    )
    chunked, _ = chunked_sampler.ddpm_step(
        states,
        t_scalar=0.5,
        dt=0.1,
        generator=torch.Generator().manual_seed(91),
        microbatch_size=2,
    )
    torch.testing.assert_close(chunked, full)
    assert full_sampler.nfe == 1
    assert chunked_sampler.nfe == 3


def test_unconditional_config_rejects_prompt_or_fixed_prefix() -> None:
    config = minimal_config()
    with_prompt = copy.deepcopy(config)
    with_prompt["decoder"]["prompt"] = "fake"
    with pytest.raises(ValueError, match="prompt: null"):
        decoder_id(with_prompt)
    with_prefix = copy.deepcopy(config)
    with_prefix["decoder"]["fixed_prefix_token_ids"] = [0]
    with pytest.raises(ValueError, match="empty fixed prefix"):
        decoder_id(with_prefix)


def test_unconditional_and_prompt_conditioned_decoders_have_different_ids() -> None:
    unconditional = minimal_config()
    conditioned = copy.deepcopy(unconditional)
    conditioned["decoder"]["generation_mode"] = "fixed_prefix"
    conditioned["decoder"]["fixed_prefix_token_ids"] = [0, 42]
    conditioned["decoder"]["prompt"] = "legacy prompt"
    assert decoder_id(unconditional) != decoder_id(conditioned)


def test_log_potentials_telescope() -> None:
    beta = [0.0, 0.3, 0.7, 2.0]
    rewards = [0.0, -1.2, -0.4, -0.1]
    assert sum(telescoping_log_increments(beta, rewards)) == pytest.approx(
        beta[-1] * rewards[-1]
    )


def test_checkpoint_schedule_telescopes_to_terminal_lambda_reward() -> None:
    terminal_lambda = 4.0
    checkpoint_levels = [0, 4, 8, 12, 16, 20, 24, 28, 32]
    beta = [terminal_lambda * level / 32 for level in checkpoint_levels]
    rewards = [0.0, -6.0, -4.5, -3.0, -2.0, -1.0, -0.5, -0.2, -0.1]
    increments = telescoping_log_increments(beta, rewards)
    assert sum(increments) == pytest.approx(terminal_lambda * rewards[-1])
    assert beta[-1] == terminal_lambda


def test_unconditional_event_text_is_retokenized_and_trimmed() -> None:
    class CharacterTokenizer:
        def encode(self, text, add_special_tokens=False):
            del add_special_tokens
            return [ord(character) for character in text]

        def decode(self, token_ids):
            return "".join(chr(value) for value in token_ids)

    text, token_ids = unconditional_trimmed_classifier_text(
        decoded_text="abcdef",
        trimming_tokenizer=CharacterTokenizer(),
        completion_tokens=3,
    )
    assert token_ids == [ord("a"), ord("b"), ord("c")]
    assert text == "abc"


def test_log_weight_normalization() -> None:
    normalized = normalize_log_weights(torch.tensor([1000.0, 999.0, -torch.inf]))
    assert float(torch.logsumexp(normalized, dim=0)) == pytest.approx(0.0)
    assert normalized[-1].item() == -torch.inf


def test_all_negative_infinite_weights_are_rejected() -> None:
    with pytest.raises(ValueError, match="at least one"):
        normalize_log_weights(torch.tensor([-torch.inf, -torch.inf]))


@pytest.mark.parametrize("method", ["multinomial", "systematic", "stratified"])
def test_all_resampling_methods(method: str) -> None:
    indices = resample_indices(
        torch.log(torch.tensor([0.7, 0.2, 0.1])),
        method=method,
        generator=torch.Generator().manual_seed(4),
    )
    assert indices.shape == (3,)
    assert bool(((indices >= 0) & (indices < 3)).all())


def test_target_samples_and_resume_without_duplicates(tmp_path: Path) -> None:
    config = minimal_config()
    identifier = decoder_id(config)
    run_dir = tmp_path / identifier
    initialize_manifest(
        run_dir,
        {"decoder_id": identifier, "decoder_manifest": decoder_manifest(config)},
    )
    atomic_write_jsonl(
        run_dir / "generations" / "shard_00000000_00000001.jsonl",
        [
            generation_row(sample_id="a", sample_index=0, identifier=identifier),
            generation_row(sample_id="b", sample_index=1, identifier=identifier),
        ],
    )
    inventory = scan_direct_generations(run_dir, identifier)
    assert inventory.count == 2
    assert missing_indices(inventory, target=4) == [2, 3]
    assert missing_indices(inventory, target=2) == []


def test_manifest_mismatch_is_rejected(tmp_path: Path) -> None:
    run_dir = tmp_path / "run"
    initialize_manifest(run_dir, {"decoder_id": "a"})
    with pytest.raises(ValueError, match="manifest mismatch"):
        initialize_manifest(run_dir, {"decoder_id": "b"})


def test_direct_summary_growth_is_append_only_and_latest_is_selected(tmp_path: Path) -> None:
    first = {"evaluated_samples": 2, "empirical_probability": 0.0}
    extended = {"evaluated_samples": 256, "empirical_probability": 0.01}
    _write_summary_snapshot(tmp_path, first)
    legacy_text = (tmp_path / "summary.json").read_text(encoding="utf-8")
    _write_summary_snapshot(tmp_path, extended)
    assert (tmp_path / "summary.json").read_text(encoding="utf-8") == legacy_text
    latest = latest_direct_summary_path(tmp_path)
    assert latest == tmp_path / "summaries" / "summary_00000256.json"
    assert json.loads(latest.read_text(encoding="utf-8")) == extended


def test_duplicate_sample_ids_are_rejected(tmp_path: Path) -> None:
    identifier = "decoder"
    atomic_write_jsonl(
        tmp_path / "generations" / "shard_00000.jsonl",
        [generation_row(sample_id="same", sample_index=0, identifier=identifier)],
    )
    atomic_write_jsonl(
        tmp_path / "generations" / "shard_00001.jsonl",
        [generation_row(sample_id="same", sample_index=1, identifier=identifier)],
    )
    with pytest.raises(ValueError, match="duplicate sample_id"):
        scan_direct_generations(tmp_path, identifier)


def test_reverse_snis_converges_on_finite_state_model() -> None:
    base = torch.tensor([0.7, 0.2, 0.1], dtype=torch.float64)
    rewards = torch.tensor([-2.0, -0.5, -0.1], dtype=torch.float64)
    events = torch.tensor([False, False, True])
    lam = 3.0
    tilted = base * torch.exp(lam * rewards)
    tilted /= tilted.sum()
    sampled = torch.multinomial(
        tilted, 100_000, replacement=True, generator=torch.Generator().manual_seed(99)
    )
    result = reverse_snis_component(
        final_log_weights=torch.full((sampled.numel(),), -math.log(sampled.numel())),
        rewards=rewards[sampled],
        events=events[sampled],
        lambda_final=lam,
    )
    assert result.estimate == pytest.approx(float(base[events].sum()), abs=0.01)


class ToySampler:
    mask_token_id = 2
    sampling_epsilon = 1e-5
    final_noise_removal = False

    def __init__(self) -> None:
        self.nfe = 0

    def initial_states(self, *, batch_size, sequence_length, device, fixed_prefix_token_ids):
        assert fixed_prefix_token_ids is None or fixed_prefix_token_ids.numel() == 0
        return (
            torch.full((batch_size, sequence_length), self.mask_token_id, device=device),
            torch.empty(0, dtype=torch.long, device=device),
        )

    def reset_nfe(self) -> None:
        self.nfe = 0

    def ddpm_step(
        self,
        states,
        *,
        t_scalar,
        dt,
        generator,
        cached_p_x0=None,
        microbatch_size=None,
    ):
        del t_scalar, dt, cached_p_x0, microbatch_size
        self.nfe += 1
        draw = torch.randint(0, 2, states.shape, device=states.device, generator=generator)
        return torch.where(states == self.mask_token_id, draw, states), None


def test_lambda_zero_reduces_to_unconditional_base_sampler() -> None:
    result = run_smc_component(
        sampler=ToySampler(),
        fixed_prefix_token_ids=torch.empty(0, dtype=torch.long),
        reward_fn=lambda tokens: tokens[:, -1].double(),
        event_fn=lambda tokens: tokens[:, -1] == 1,
        config=SMCComponentConfig(
            num_particles=32,
            num_steps=1,
            sequence_length=2,
            lambda_final=0.0,
            seed=123,
        ),
        device="cpu",
    )
    assert result.final_log_weights == pytest.approx(
        torch.full((32,), -math.log(32)), abs=1e-7
    )
    assert result.genealogy == []
    assert result.log_normalizer_estimate == pytest.approx(0.0)
    assert not bool((result.terminal_tokens == 2).any())


class TerminalCheckpointToySampler:
    mask_token_id = 2
    sampling_epsilon = 1e-5
    final_noise_removal = True

    def __init__(self) -> None:
        self.nfe = 0
        self.deterministic_completion_calls = 0
        self.terminal_completion_calls = 0

    def initial_states(self, *, batch_size, sequence_length, device, fixed_prefix_token_ids):
        assert fixed_prefix_token_ids is None or fixed_prefix_token_ids.numel() == 0
        return (
            torch.full((batch_size, sequence_length), self.mask_token_id, device=device),
            torch.empty(0, dtype=torch.long, device=device),
        )

    def reset_nfe(self) -> None:
        self.nfe = 0

    def ddpm_step(
        self,
        states,
        *,
        t_scalar,
        dt,
        generator,
        cached_p_x0=None,
        microbatch_size=None,
    ):
        del t_scalar, dt, generator, cached_p_x0, microbatch_size
        self.nfe += 1
        return states, None

    def deterministic_completion(self, states, *, t_scalar, microbatch_size=None):
        del t_scalar, microbatch_size
        self.deterministic_completion_calls += 1
        return torch.zeros_like(states)

    def terminal_completion(
        self, states, *, t_scalar, generator, microbatch_size=None
    ):
        del t_scalar, generator, microbatch_size
        self.terminal_completion_calls += 1
        return torch.ones_like(states)


def test_terminal_checkpoint_uses_true_stochastic_completion_and_beta_lambda() -> None:
    sampler = TerminalCheckpointToySampler()
    reward_inputs: list[torch.Tensor] = []

    def reward(tokens: torch.Tensor) -> torch.Tensor:
        reward_inputs.append(tokens.clone())
        return tokens[:, 0].double()

    result = run_smc_component(
        sampler=sampler,
        fixed_prefix_token_ids=torch.empty(0, dtype=torch.long),
        reward_fn=reward,
        event_fn=lambda tokens: tokens[:, 0] == 1,
        config=SMCComponentConfig(
            num_particles=4,
            num_steps=4,
            sequence_length=2,
            lambda_final=2.0,
            reward_frequency=2,
            final_resampling=False,
            seed=7,
        ),
        device="cpu",
    )

    assert sampler.deterministic_completion_calls == 1
    assert sampler.terminal_completion_calls == 1
    assert len(reward_inputs) == 2
    assert bool((reward_inputs[0] == 0).all())
    assert bool((reward_inputs[1] == 1).all())
    checkpoints = [row for row in result.level_diagnostics if row["checkpoint"]]
    assert [row["level"] for row in checkpoints] == [2, 4]
    assert [row["beta"] for row in checkpoints] == pytest.approx([1.0, 2.0])
    assert result.log_normalizer_estimate == pytest.approx(2.0)
    torch.testing.assert_close(
        result.pre_final_resampling_log_weights,
        result.post_final_resampling_log_weights,
    )


def test_two_reverse_snis_ratios_are_separate_then_averaged() -> None:
    config = load_yaml("configs/mdlm_owt_unconditional_smoke_technical.yaml")
    summaries = []
    expected_runs = []
    for run_index, estimates in enumerate(((0.2, 0.6), (0.4, 0.8))):
        expected_runs.append(sum(estimates) / 2)
        for lam, estimate in zip((5.0, 10.0), estimates):
            summaries.append(
                {
                    "run_index": run_index,
                    "lambda": lam,
                    "reverse_snis_estimate": estimate,
                }
            )
    aggregate = _aggregate(summaries, config)
    assert aggregate["component_estimates_by_run"] == [[0.2, 0.6], [0.4, 0.8]]
    assert aggregate["run_estimates"] == pytest.approx(expected_runs)
    assert aggregate["mean_reverse_snis_estimate"] == pytest.approx(
        sum(expected_runs) / 2
    )
    assert "prompt" not in json.dumps(aggregate).lower()


def test_reverse_snis_components_are_normalized_separately_before_aggregation() -> None:
    first = reverse_snis_component(
        final_log_weights=torch.log(torch.tensor([0.9, 0.1], dtype=torch.float64)),
        rewards=torch.tensor([-2.0, -0.1], dtype=torch.float64),
        events=torch.tensor([False, True]),
        lambda_final=1.0,
    )
    second = reverse_snis_component(
        final_log_weights=torch.log(torch.tensor([0.2, 0.3, 0.5], dtype=torch.float64)),
        rewards=torch.tensor([-3.0, -1.0, -0.2], dtype=torch.float64),
        events=torch.tensor([False, True, True]),
        lambda_final=2.0,
    )
    assert torch.tensor(
        first.corrected_log_weights, dtype=torch.float64
    ).logsumexp(0).item() == pytest.approx(0.0)
    assert torch.tensor(
        second.corrected_log_weights, dtype=torch.float64
    ).logsumexp(0).item() == pytest.approx(0.0)
    combined = aggregate_component_estimates(
        [first.estimate, second.estimate], [0.5, 0.5]
    )
    assert combined == pytest.approx((first.estimate + second.estimate) / 2)


def test_generic_aggregator_accepts_nonuniform_simplex_weights() -> None:
    assert aggregate_component_estimates([0.1, 0.9], [0.25, 0.75]) == pytest.approx(
        0.25 * 0.1 + 0.75 * 0.9
    )


def test_direct_unconditional_baseline_has_binomial_se_and_wilson() -> None:
    rows = [
        {"conditioning_mode": "unconditional", "is_event": value}
        for value in (True, False, False, False)
    ]
    summary = direct_unconditional_summary(rows)
    assert summary["empirical_probability"] == pytest.approx(0.25)
    assert summary["binomial_standard_error"] == pytest.approx(
        math.sqrt(0.25 * 0.75 / 4)
    )
    assert 0 <= summary["wilson_95_low"] <= summary["wilson_95_high"] <= 1
    assert "prompt" not in json.dumps(summary).lower()


def test_smoke_profiles_are_unconditional_distinct_and_uniform() -> None:
    technical = load_yaml("configs/mdlm_owt_unconditional_smoke_technical.yaml")
    scientific = load_yaml("configs/mdlm_owt_unconditional_smoke_scientific.yaml")
    assert decoder_id(technical) != decoder_id(scientific)
    for config in (technical, scientific):
        decoder = config["decoder"]
        assert decoder["generation_mode"] == "unconditional"
        assert decoder["fixed_prefix_token_ids"] == []
        assert decoder["prompt"] is None
        assert config["direct"]["target_samples"] == 2
        assert config["smc"]["tilted_lambdas"] == [5.0, 10.0]
        assert config["smc"]["tilted_component_weights_a"] == [0.5, 0.5]
        manifest = smc_manifest(config)
        assert manifest["decoder_id"] == decoder_id(config)
        assert manifest["diagnostic_components"] == {
            "lambdas": [0.0],
            "included_in_tilted_component_aggregation": False,
        }
        assert "prompt" not in json.dumps(manifest).lower()


def test_direct_and_smc_unconditional_use_the_same_decoder_id() -> None:
    config = load_yaml("configs/mdlm_owt_unconditional_smoke_technical.yaml")
    identifier = decoder_id(config)
    assert direct_run_directory(config).name == identifier
    assert smc_manifest(config)["decoder_id"] == identifier


def test_current_uniform_policy_and_future_explicit_policy() -> None:
    config = load_yaml("configs/mdlm_owt_unconditional_common.yaml")
    nonuniform = copy.deepcopy(config)
    nonuniform["smc"]["tilted_component_weights_a"] = [0.25, 0.75]
    with pytest.raises(ValueError, match="1/J"):
        smc_manifest(nonuniform)
    nonuniform["smc"]["component_weight_policy"] = "explicit"
    assert smc_manifest(nonuniform)["tilted_component_aggregation"]["weights_a"] == [
        0.25,
        0.75,
    ]


def test_lambda_zero_is_diagnostic_not_aggregated() -> None:
    config = load_yaml("configs/mdlm_owt_unconditional_smoke_technical.yaml")
    manifest = smc_manifest(config)
    assert 0.0 not in manifest["tilted_component_aggregation"]["tilted_lambdas"]
    assert manifest["diagnostic_components"]["lambdas"] == [0.0]
    assert manifest["diagnostic_components"][
        "included_in_tilted_component_aggregation"
    ] is False


def test_calibration_components_are_never_aggregated() -> None:
    config = load_yaml("configs/mdlm_owt_unconditional_lambda_calibration.yaml")
    validate_benchmark_config(config)
    manifest = smc_manifest(config)
    assert manifest["experiment_phase"] == "calibration"
    assert manifest["calibration_components"] == {
        "lambdas": [0.5, 1.0, 2.0, 4.0],
        "aggregation_performed": False,
        "purpose": "terminal-lambda selection only",
    }
    assert "tilted_component_aggregation" not in manifest
    assert manifest["diagnostic_components"]["lambdas"] == [0.0]
    assert config["smc"]["num_particles"] == 256
    assert config["smc"]["num_independent_runs"] == 1


def test_progressive_lambda_calibration_is_dense_bounded_and_not_aggregated() -> None:
    config = load_yaml("configs/mdlm_owt_unconditional_lambda_progressive.yaml")
    validate_benchmark_config(config)
    manifest = smc_manifest(config)
    assert config["smc"]["calibration_lambdas"] == [
        0.25,
        0.5,
        0.75,
        1.0,
        1.25,
        1.5,
        1.75,
        2.0,
    ]
    assert max(config["smc"]["calibration_lambdas"]) == 2.0
    assert config["smc"]["num_particles"] == 256
    assert config["smc"]["num_independent_runs"] == 1
    assert manifest["experiment_phase"] == "calibration"
    assert manifest["calibration_components"]["aggregation_performed"] is False
    assert manifest["diagnostic_components"]["lambdas"] == [0.0]
    assert "tilted_component_aggregation" not in manifest


def test_100_token_estimation_uses_independent_components_and_uniform_average() -> None:
    config = load_yaml("configs/mdlm_owt_unconditional_estimation_100tok.yaml")
    validate_benchmark_config(config)
    smc = config["smc"]
    assert smc["experiment_phase"] == "estimation"
    assert smc["tilted_lambdas"] == [0.25, 0.5, 0.75, 1.0]
    assert smc["tilted_component_weights_a"] == [0.25] * 4
    assert smc["num_particles"] == 512
    assert smc["component_rng_policy"] == "independent_seed_per_run_and_component"
    seeds = [
        _component_seed(smc, run_index=0, component_index=index)
        for index in range(4)
    ]
    assert seeds == [67000, 67001, 67002, 67003]
    assert len(set(seeds)) == 4
    assert config["evaluation"]["reward"] == config["evaluation"]["event"] | {
        "definition": "log_softmax_probability_of_positive_toxicity_class"
    }
    manifest = smc_manifest(config)
    aggregation = manifest["tilted_component_aggregation"]
    assert aggregation["aggregation"] == "p_hat = sum_j a_j * p_hat_j"
    assert aggregation["weights_a"] == [0.25] * 4
    assert manifest["diagnostic_components"]["lambdas"] == []


class _PrefixTokenizer:
    def decode(self, token_ids, skip_special_tokens=True):
        assert skip_special_tokens
        return " ".join(str(value) for value in token_ids)

    def batch_decode(self, rows, skip_special_tokens=True):
        return [self.decode(row, skip_special_tokens=skip_special_tokens) for row in rows]


class _RecordingEvaluator:
    def __init__(self) -> None:
        self.calls = []

    def score_texts(self, texts, *, max_length):
        self.calls.append((list(texts), max_length))
        return [
            {
                "reward": -0.5,
                "logits": [0.5, -0.5],
                "toxic_probability": 0.25,
                "is_event": False,
            }
            for _ in texts
        ]


def test_reward_and_event_use_the_identical_100_mdlm_token_text() -> None:
    tokenizer = _PrefixTokenizer()
    evaluator = _RecordingEvaluator()
    functions = UnconditionalToxicityFunctions(
        generator_tokenizer=tokenizer,
        evaluator=evaluator,
        reward_completion_tokens=100,
        event_completion_tokens=100,
        reward_max_length=512,
        event_max_length=512,
        event_text_scope="first_generated_mdlm_tokens_only",
        completion_trimming_tokenizer=object(),
    )
    tokens = torch.arange(128).repeat(2, 1)
    functions.reward(tokens)
    functions.event(tokens)
    assert evaluator.calls[0] == evaluator.calls[1]
    assert evaluator.calls[0][1] == 512
    assert len(evaluator.calls[0][0][0].split()) == 100
    assert functions.last_event_token_ids == [list(range(100)), list(range(100))]


def test_mdlm_prefix_classifier_text_does_not_retokenize() -> None:
    text, token_ids = unconditional_mdlm_prefix_classifier_text(
        token_ids=list(range(128)),
        decoder_tokenizer=_PrefixTokenizer(),
        completion_tokens=100,
    )
    assert token_ids == list(range(100))
    assert len(text.split()) == 100


def test_estimation_template_is_provisional_uniform_and_excludes_lambda_zero() -> None:
    config = load_yaml("configs/mdlm_owt_unconditional_estimation_template.yaml")
    validate_benchmark_config(config)
    manifest = smc_manifest(config)
    aggregation = manifest["tilted_component_aggregation"]
    assert aggregation["tilted_lambdas"] == [0.5, 1.0, 2.0]
    assert aggregation["weights_a"] == pytest.approx([1 / 3, 1 / 3, 1 / 3])
    assert 0.0 not in aggregation["tilted_lambdas"]
    assert manifest["diagnostic_components"]["lambdas"] == [0.0]
    assert config["smc"]["num_particles"] == 256
    assert config["smc"]["microbatch_size"] == 16


def test_calibration_and_direct_32_use_identical_decoder() -> None:
    calibration = load_yaml("configs/mdlm_owt_unconditional_lambda_calibration.yaml")
    direct = load_yaml("configs/mdlm_owt_unconditional_direct_32.yaml")
    assert decoder_id(calibration) == decoder_id(direct)


def test_calibration_report_keeps_components_separate(tmp_path: Path) -> None:
    config = load_yaml("configs/mdlm_owt_unconditional_lambda_calibration.yaml")
    decoder = decoder_id(config)
    evaluator = evaluator_id(config)
    direct_run = tmp_path / "direct"
    eval_dir = direct_run / "evaluations" / evaluator
    _write_summary_snapshot(
        eval_dir,
        {
            "decoder_id": decoder,
            "evaluator_id": evaluator,
            "conditioning_mode": "unconditional",
            "evaluated_samples": 100,
            "empirical_probability": 0.1,
        },
    )

    def component(role: str, lam: float, fraction: float) -> dict:
        return {
            "component_role": role,
            "lambda": lam,
            "num_particles": 64,
            "tilted_event_fraction_not_p0_estimate": fraction,
            "tilted_event_discoveries": int(64 * fraction),
            "reverse_snis_estimate": 0.1,
            "reverse_weight_ess": 32.0,
            "reverse_weight_ess_over_n": 0.5,
            "resampling_count": 1,
            "distinct_root_ancestors": 40,
            "distinct_root_ancestor_fraction": 0.625,
            "pre_final_resampling_max_normalized_weight": 0.1,
            "reverse_max_normalized_weight": 0.2,
            "reward_quantiles": {
                "q00": -5.0,
                "q10": -4.0,
                "q25": -3.0,
                "q50": -2.0,
                "q75": -1.0,
                "q90": -0.5,
                "q100": -0.1,
            },
            "runtime_seconds": 1.0,
            "nfe": 40,
            "classifier_model_forward_calls": 10,
            "classifier_texts_scored": 128,
            "peak_cuda_memory_allocated_bytes": 123,
            "nonfinite_detected": False,
        }

    calibration_run = tmp_path / "calibration"
    calibration_run.mkdir()
    (calibration_run / "summary.json").write_text(
        json.dumps(
            {
                "decoder_id": decoder,
                "evaluator_id": evaluator,
                "conditioning_mode": "unconditional",
                "experiment_phase": "calibration",
                "aggregation_performed": False,
                "diagnostic_components": [component("diagnostic", 0.0, 0.125)],
                "calibration_components": [component("calibration", 1.0, 0.25)],
            }
        ),
        encoding="utf-8",
    )
    report, destination = build_calibration_report(
        config,
        direct_run=direct_run,
        calibration_run=calibration_run,
    )
    assert report["aggregation_performed"] is False
    assert report["selection_performed"] is False
    assert [row["component_role"] for row in report["components"]] == [
        "diagnostic",
        "calibration",
    ]
    assert "aggregate" not in report
    assert (destination / "direct_00000100.csv").exists()


def test_setuptools_discovers_only_explicit_python_packages() -> None:
    repository_root = Path(__file__).resolve().parents[1]
    with (repository_root / "pyproject.toml").open("rb") as handle:
        discovery = tomllib.load(handle)["tool"]["setuptools"]["packages"]["find"]
    discovered = set(
        find_packages(
            where=str(repository_root),
            include=tuple(discovery["include"]),
            exclude=tuple(discovery["exclude"]),
        )
    )
    assert discovered == {
        "rea_llms",
        "rea_llms.observables",
        "suffix_direct_mh_smc_experiment",
        "official_annealed_tps_experiment",
        "diffusion_toxicity_smc_experiment",
    }


def test_comparison_rejects_different_decoder_ids(tmp_path: Path) -> None:
    config = minimal_config()
    evaluator = evaluator_id(config)
    direct_run = tmp_path / "direct"
    evaluation_dir = direct_run / "evaluations" / evaluator
    evaluation_dir.mkdir(parents=True)
    (evaluation_dir / "summary.json").write_text(
        json.dumps(
            {
                "decoder_id": "prompt-conditioned-old-id",
                "evaluator_id": evaluator,
                "conditioning_mode": "unconditional",
            }
        ),
        encoding="utf-8",
    )
    smc_run = tmp_path / "smc"
    smc_run.mkdir()
    (smc_run / "summary.json").write_text(
        json.dumps(
            {
                "decoder_id": decoder_id(config),
                "evaluator_id": evaluator,
                "conditioning_mode": "unconditional",
            }
        ),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="decoder_id"):
        compare_existing(config, direct_run=direct_run, smc_run=smc_run)


@pytest.mark.slow
@pytest.mark.gpu
def test_optional_real_unconditional_model_smoke_is_explicitly_opt_in() -> None:
    if os.environ.get("RUN_MDLM_GPU_INTEGRATION") != "1":
        pytest.skip("set RUN_MDLM_GPU_INTEGRATION=1 with pinned artifacts to run")
    config = load_yaml("configs/mdlm_owt_unconditional_smoke.yaml")
    runtime = load_generator_runtime(config, local_files_only=True)
    decoder = config["decoder"]
    sampler = NativeMDLMSampler(
        runtime.model,
        mask_token_id=int(decoder["mask_token_id"]),
        predictor="ddpm",
        final_noise_removal=True,
    )
    tokens = sampler.sample(
        batch_size=1,
        sequence_length=int(decoder["sequence_length"]),
        num_steps=2,
        fixed_prefix_token_ids=torch.empty(0, dtype=torch.long, device=runtime.device),
        device=runtime.device,
        generator=torch.Generator(device="cuda").manual_seed(1),
    )
    assert tokens.shape == (1, int(decoder["sequence_length"]))
    assert not bool((tokens == int(decoder["mask_token_id"])).any())
